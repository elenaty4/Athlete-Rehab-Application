/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

/**
 *
 * @author elngo
 */
public class Trainer extends User {
    
    public Trainer()
    {
        super._userType = UserType.TRAINER;
    }
    
    
    //getters
    @Override
    public String getFullName()
    {
        return super.getFullName();
    }
    
    @Override
    public String getFirstName()
    {
        return super.getFirstName();
    }
    
    @Override
    public String getLastName()
    {
        return super.getLastName();
    }
    
    @Override
    public String getPassword()
    {
        return super.getPassword();
    }
    
    @Override
    public String getEmail()
    {
        return super.getEmail();
    }
    
    @Override
    public UserType getUserType()
    {
        return super.getUserType();
    }
    
    //toString
    @Override
    public String toString()
    {
        String toReturn = super.toString();
        return toReturn;
    }
}
