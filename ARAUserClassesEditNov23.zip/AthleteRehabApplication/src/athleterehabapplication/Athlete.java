/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.util.ArrayList;

/**
 * @author Elena Ngo
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A
 */
public class Athlete extends User {
    
    private ArrayList<InjuryReport> _listOfTheirReports;
    private Plan _theirPlan;
    
    public Athlete()
    {
        super._userType = UserType.ATHLETE;
    }
    
    //boolean methods
    public boolean hasReport()
    {
        //check if the array is empty
        boolean toReturn = false;
        if(!_listOfTheirReports.isEmpty()) //if not empty
        {
            toReturn = true;
        }
        return toReturn;
    }
    
    public boolean hasPlan()
    {
        //if Plan exists. PLAN MUST HAVE A BOOLEAN EXIST() METHOD
        boolean toReturn = false;
        return toReturn;
    }
    
    //getters
    @Override
    public String getFullName()
    {
        return super.getFullName();
    }
    
    @Override
    public String getFirstName()
    {
        return super.getFirstName();
    }
    
    @Override
    public String getLastName()
    {
        return super.getLastName();
    }
    
    @Override
    public String getPassword()
    {
        return super.getPassword();
    }
    
    @Override
    public String getEmail()
    {
        return super.getEmail();
    }
    
    @Override
    public UserType getUserType()
    {
        return super.getUserType();
    }
    
    public ArrayList<InjuryReport> getReportList()
    {
        return _listOfTheirReports;
    }
    
    public Plan getTheirPlan()
    {
        return _theirPlan;
    }
    
    //toString method
    @Override
    /**
     * 
     */
    public String toString()
    {
        String toReturn = super.toString() + "\n" + "List of Reports: \n";
        for (int i = 0; i < _listOfTheirReports.size(); i++)
        {
            toReturn = toReturn + _listOfTheirReports.get(i).toString() + "\n";
        }
        toReturn = toReturn + _theirPlan.toString();
        
        return toReturn;        
    }
    
}
