/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.util.ArrayList;

/**
 * @author Elena Ngo
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A
 */
public class RegisteredUsers {
    private ArrayList<Athlete> _registeredAthletes;
    private ArrayList<Trainer> _registeredTrainers;
    
    public RegisteredUsers()
    {
        //constructor instantiates the ArrayLists
        _registeredAthletes = new ArrayList<>();
        _registeredTrainers = new ArrayList<>();
    }
    
    
    //getters
    public ArrayList<Athlete> getRegisteredAthletes()
    {
        return _registeredAthletes;
    }
    
    public ArrayList<Trainer> getRegisteredTrainers()
    {
        return _registeredTrainers;
    }
    
    public void addAthlete(Athlete Athlete)
    {
        _registeredAthletes.add(Athlete);
    }
    
    public void addTrainer(Trainer trainer)
    {
        _registeredTrainers.add(trainer);
    }
    
    
    
    
    //toString
    @Override
    public String toString()
    {
        return null;
    }
}
