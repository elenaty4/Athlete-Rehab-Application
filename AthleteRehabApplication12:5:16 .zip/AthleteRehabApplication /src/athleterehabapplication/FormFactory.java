/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

/**
 * @author Tim Yarosh
 * @version 1.0
 * @date 11/30/16
 * @section CS275.A
 */
public class FormFactory {

    private static FormFactory _instance;

    public static FormFactory getInstance() {
        return _instance;        
    }

    public Form getFormType(FormType formType) {
        switch (formType) {
            case REGISTER:
                return new RegisterForm();

            case INJURY_REPORT:
                return new InjuryReportForm();

            case CREATE_PLAN:
                return new PlanForm();

            default:
                return null;
        }
    }
}
