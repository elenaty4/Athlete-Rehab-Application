/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * @author Tim Yarosh
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A
 */
public abstract class Form {

    private static ArrayList<String> _formQuestions;

    public Form() {
        _formQuestions = new ArrayList<>();
    }

    public void addQuestion(String question) {
        _formQuestions.add(question);
    }

    //accessor
    public static ArrayList<String> getQuestions() {
        return _formQuestions;
    }

    @Override
    public String toString() {
        String toReturn = Arrays.toString(_formQuestions.toArray());
        return toReturn;

    }
}
