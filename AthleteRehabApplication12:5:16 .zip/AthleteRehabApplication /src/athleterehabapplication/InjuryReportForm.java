/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * @author Tim Yarosh
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A
 */
public class InjuryReportForm extends Form {

    private ArrayList<String> _questions;

    public InjuryReportForm() {
        _questions = getQuestions();
    }

    public void createReport() {

        InjuryReportData data = new InjuryReportData();
        data._firstName = "first"; //this needs to be pulled from Form. 
        //It will be whatever they put into the textfield.
        data._lastName = "last"; //this needs to be pulled from Form
        data._identifier = "email"; //tis needs to be pulled from Form
        data._dayInjuryOccured = "Monday"; //this needs to be pulled from Form
        data._injuryDuration = "1 day"; //this needs to be pulled from Form
        data._intensity = "4"; //this needs to be pulled from Form

        InMemoryStorage storage = new InMemoryStorage();
        storage.createInjuryReport(data);
    }

    public ArrayList<InjuryReport> findInjuryReports(String identifier) {

        InMemoryStorage storage = new InMemoryStorage();

        return storage.findInjuryReports(identifier);
    }

    public ArrayList<InjuryReport> getAllInjuryReports() {

        InMemoryStorage storage = new InMemoryStorage();

        return storage.getAllInjuryReports();
    }

    //getter
    public static ArrayList<String> getQuestions() {
        return Form.getQuestions();
    }

    //toString
    @Override
    public String toString() {
        String toReturn = Arrays.toString(_questions.toArray());

        return toReturn;
    }
}
