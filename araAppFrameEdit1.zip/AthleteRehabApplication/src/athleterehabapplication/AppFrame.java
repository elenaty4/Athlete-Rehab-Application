/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.awt.BorderLayout;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.*;
/**
 * This class is a Facade that will instantiate other classes so it can be put
 * in it's frame components
 * @author Elena Ngo, CS275
 * @version 1.0, November 14, 2016
 */
public class AppFrame extends JFrame {
    
    final private int FRAME_WIDTH = 800; //numbers are subject to change
    final private int FRAME_HEIGHT= 600;
    
    private JPanel _panel;
    private JButton _button;
    private JTextField _textField;
    private FormFactory _formF;
    private RegisteredUsers _rUsers;
    
    private ActionListener _listener; //listens to what the mouse clicks
    
    public AppFrame()
    {
        //will call loginComponent
        //and then AthleteMenu Component and so on
        loginComponent();
        setSize(FRAME_WIDTH, FRAME_HEIGHT);
    }
    
    private void loginComponent() //private method because it is only used in this class
    {
        //USE DIMENSIONS INSTEAD OF BORDERLAYOUT TO POSITION PANELS
        int fieldSize = 20;
        //starts off with a LOGIN SCREEN
        _rUsers = new RegisteredUsers();
        _formF = new FormFactory();
        _listener = new ClickListener();
        _panel = new JPanel();
        
        //CREATE LOGIN PAGE
        //HOW TO PUT COMPONENTS IN A FIXED POSITION
        _panel.setLayout(null); //panel shouldn't have a layout for this
        

        //Labels
        JLabel titleLabel = new JLabel("Welcome to the Athlete Rehab Application. Please "
                + "login or register.");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20)); //changing the size of the font
        JLabel emailLabel = new JLabel("Email: ");
        emailLabel.setFont(new Font("Arial", Font.BOLD, 16));
        JLabel passwordLabel = new JLabel("Password: ");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 16));
        
        //TextFields
        JTextField emailField = new JTextField(fieldSize);
        JTextField passField = new JTextField(fieldSize);
        emailField.addActionListener(_listener);
        passField.addActionListener(_listener);
        
        //buttons
        JButton login = new JButton("Login");
        JButton register = new JButton("Register");
        login.addActionListener(_listener);
        register.addActionListener(_listener);
        
        //putting them all in the _panel
        _panel.add(titleLabel);
        _panel.add(emailLabel);
        _panel.add(passwordLabel);
        _panel.add(emailField);
        _panel.add(passField);
        _panel.add(login);
        _panel.add(register);

        Insets insets = _panel.getInsets();
        Dimension size = titleLabel.getPreferredSize();
        //Setting the position. 
        //setbounds (Horizontal <Left or Right>, Vertical <top or bottom>, width, height)
        titleLabel.setBounds(10 + insets.right, 5 + insets.top,
                     size.width, size.height); 
        size = emailLabel.getPreferredSize();
        emailLabel.setBounds(200 + insets.left, 150 + insets.top, size.width,
                size.height);
        size = passwordLabel.getPreferredSize();
        passwordLabel.setBounds(200 + insets.left, 220 + insets.top, size.width,
                size.height);
        
        size = emailField.getPreferredSize();
        emailField.setBounds(300 + insets.left, 145 + insets.top, size.width, 25);
        size = passField.getPreferredSize();
        passField.setBounds(300 + insets.left, 215 + insets.top, size.width, 25);
        
        size = login.getPreferredSize();
        login.setBounds(360 + insets.left, 300 + insets.top, size.width,
                size.height);
        size = register.getPreferredSize();
        register.setBounds(352 + insets.left, 350 + insets.top, size.width,
                size.height);

        add(_panel);
    }
    
    //more methods may be created soon
    
    /**
    * This class listens to the user's clicks in the application
    */    
    public class ClickListener implements ActionListener{
        
        @Override
        public void actionPerformed(ActionEvent event)
        {
            
        }
    }
}
