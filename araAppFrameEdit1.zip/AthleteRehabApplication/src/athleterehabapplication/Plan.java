/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.util.Date; //timestamps the time the Plan was created

/**
 *
 * @author elngo
 */
public class Plan {
    
    private Date _timeItWasCreated;
    private String _description;
    private String _instructions;
    private String _estimatedDuration; //string will change to something else soon
    
    //getters
    public Date getTimeCreated()
    {
        return _timeItWasCreated;
    }
    
    public String getDescription()
    {
        return _description;
    }
    
    public String getInstructions()
    {
        return _instructions;
    }
    
    public String getEstimatedDuration()
    {
        return _estimatedDuration;
    }
    
    //toString
    @Override
    public String toString()
    {
        
    }
}
