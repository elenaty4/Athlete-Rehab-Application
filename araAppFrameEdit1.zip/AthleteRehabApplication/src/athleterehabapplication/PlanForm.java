/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.util.ArrayList;

/**
 *
 * @author elngo
 */
public class PlanForm extends Form {
    private Plan _plan;
    
    public PlanForm()
    {
        //constructor will put the questions the form has into the ArrayList of questions
    }
    
    public Plan createPlan()
    {
        
    }
    
    //getter
    @Override
    public ArrayList<String> getQuestions()
    {
        return super.getQuestions();
    }
    
    //toString
    @Override
    public String toString()
    {
        
    }    
}
