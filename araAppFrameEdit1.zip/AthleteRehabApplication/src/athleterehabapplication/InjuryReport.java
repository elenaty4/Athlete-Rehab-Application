/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.util.Date; //timestamps the time the InjuryReport was submitted

/**
 *
 * @author elngo
 */
public class InjuryReport {
    
    private Date _timeItSubmitted;
    private String _timeInjuryOccured; //the month, day and hour. The String type may change
    private String _injuryDuration; //the String type may change
    private String _description;
    private int _intensity;
    
    //getters
    public Date getTimeItSubmitted()
    {
        return _timeItSubmitted;
    }
    
    public String getTimeInjuryOccured()
    {
        return _timeInjuryOccured;
    }
    
    public String getInjuryDuration()
    {
        return _injuryDuration;
    }
    
    public String getDescription()
    {
        return _description;
    }
    
    public int getIntensity()
    {
        return _intensity;
    }
    
    //toString method
    @Override
    public String toString()
    {
        
    }
}
