/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

/**
 * @author Elena Ngo
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A
 */
public class User {
    private String _fullName;
    private String _firstName;
    private String _lastName;
    private String _email;
    private String _password;
    
    UserType _userType;
    
    //getters
    public String getFullName()
    {
        return _fullName;
    }
    
    public String getFirstName()
    {
        return _firstName;
    }
    
    public String getLastName()
    {
        return _lastName;
    }
    
    public String getPassword()
    {
        return _password;
    }
    
    public String getEmail()
    {
        return _email;
    }
    
    public UserType getUserType()
    {
        return _userType;
    }
    
    //toString method
    //returns a string representation of the object
    @Override
    /**
     * 
     */
    public String toString()
    {
        String toReturn = "User Type: " + _userType + "\n"
                + "Name: " + _fullName + "\n" + "Email: " + _email;
        //password will not be displayed during to security reasons
        return toReturn;
    }
}
