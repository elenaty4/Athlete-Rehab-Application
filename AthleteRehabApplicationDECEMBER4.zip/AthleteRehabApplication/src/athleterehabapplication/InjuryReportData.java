/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

/**
 *
 * @author Tim
 */
public class InjuryReportData {

    public String _identifier;
    public String _dayInjuryOccured;
    public String _injuryDuration;
    public String _intensity;
    public String _firstName;
    public String _lastName;
}
