/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import javax.swing.JFrame;
import javax.swing.ImageIcon;

/**
 * @author Elena Ngo
 * @author Tim Yarosh
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A
 */
public class AthleteRehabApplication {
    
    //IF YOU ARE NEW THIS GROUP PLEASE READ MY INSTRUCTIONAL COMMENTS ON
    //The Appframe class
    //and the User hierarchy classes
    // -Elena Ngo
    
    public static void runApplication()
    {
        JFrame frame = new AppFrame();
        frame.setTitle("Athlete Rehab Application");
        ImageIcon img = new ImageIcon("frameicon.png");
            frame.setIconImage(img.getImage());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true); //visibility of the frame. True makes it visible
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        runApplication();
    }

}
