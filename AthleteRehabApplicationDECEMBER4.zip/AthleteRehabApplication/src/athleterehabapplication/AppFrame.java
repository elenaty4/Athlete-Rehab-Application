/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.*;
import java.util.ArrayList;


/**
 * @author Elena Ngo
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A 
 */
public class AppFrame extends JFrame {
    
    //These ints hold the default size of the frame
    final private int FRAME_WIDTH = 800; //numbers are subject to change
    final private int FRAME_HEIGHT= 600;
    
    //instead of making different types of labels and textfields make one member data that will CONSTANTLY change
    
    //like this _panel
    private JPanel _panel; //the panel holds all of the components of the frame
    
    //Various Buttons that have to be member data so that the ClickListener class can use them
    private JButton _login; //The login button that is clickable
    private JButton _register; //The register button that is clickable
    private JButton _submitRegister; //The "Submit" button in the register screen
    private JButton _goBackRegister; //The "Go Back" button in the register screen
    
    //User will type in their email and password in these fields. 
    //The words that they type in will be read once they click on the login button
    //Note that JPasswordField is ALSO a textField but when the user types something
    //in there the words are replaced by dots for security
    private JTextField _emailField;
    private JTextField _firstNameField;
    private JTextField _lastNameField;
    private JPasswordField _passField; 
    
    private JLabel _label;
    
    private JComboBox<String> _selectUserType; //drop down box of Athlete and Trainer
    
    private Insets _insets;
    
    
    private FormFactory _formF;
    
    private RegisteredUsers _rUsers; //holds the list of users who are registered.
    
    private ActionListener _listener; //listens to what the mouse clicks. It's like
    //a scanner for the mouse clicking
    
    
    //THE METHODS BELOW CONSIST OF ADDING COMPONENTS TO THE FRAME. THEY ARE SEPARATED
    //INTO DIFFERENT PARTS:
    //loginComponents() adds the GUI components for the Login screen
    //formComponents() adds the Register Screen components, Injury Report Form components,
    //and the creat Plan form components
    
    //The ClickListener class in this AppFrame class is only there to scan what
    //the mouse clicked on and change the screen from it
    
    /**
     * 
     */
    public AppFrame()
    {
        //will call loginComponent
        //and then AthleteMenu Component and so on
        getContentPane().setBackground(Color.RED);
        loginComponents();
        setSize(FRAME_WIDTH, FRAME_HEIGHT);
    }
    
    /**
     * 
     */
    private void loginComponents() //private method because it is only used in this class
    {
        //USE DIMENSIONS INSTEAD OF BORDERLAYOUT TO POSITION PANELS
        int fieldSize = 20;
        //starts off with a LOGIN SCREEN
        _rUsers = new RegisteredUsers();
        _formF = new FormFactory();
        _listener = new ClickListener();
        _panel = new JPanel();
        
        //CREATE LOGIN PAGE
        _panel.setLayout(null); //panel shouldn't have a layout for exact positioning
        _insets = _panel.getInsets();
        Dimension size;
        
        //LABELS
        
        //titleLabel
        _label = new JLabel("Welcome to the Athlete Rehab Application");
        _label.setFont(new Font("Arial", Font.BOLD, 20));
        _label.setForeground(Color.WHITE);
        _panel.add(_label);
        size = _label.getPreferredSize();
        _label.setBounds(10 + _insets.right, 5 + _insets.top, size.width, size.height); 
        
        //instruction Label
        _label = new JLabel("Please enter your email and password below. And then click Login. "
                + "If you haven't signed up yet, click on Register");
        _label.setFont(new Font("Arial", Font.PLAIN, 14));
        _label.setForeground(Color.WHITE);
        _panel.add(_label);
        size = _label.getPreferredSize();
        _label.setBounds(10 + _insets.right, 40 + _insets.top, size.width,
                size.height);
        
        //email Label
        _label = new JLabel("Email: ");
        _label.setFont(new Font("Arial", Font.BOLD, 16));
        _label.setForeground(Color.WHITE);
        _panel.add(_label);
        size = _label.getPreferredSize();
        _label.setBounds(200 + _insets.left, 150 + _insets.top, size.width,
                size.height);
        
        //password label
        _label = new JLabel("Password: ");
        _label.setFont(new Font("Arial", Font.BOLD, 16));
        _label.setForeground(Color.WHITE);
        _panel.add(_label);
        size = _label.getPreferredSize();
        _label.setBounds(200 + _insets.left, 220 + _insets.top, size.width,
                size.height);
        
        //TEXTFIELDS
        _emailField = new JTextField(fieldSize); //the email field
        _emailField.addActionListener(_listener);
        _panel.add(_emailField);
        size = _emailField.getPreferredSize();
        _emailField.setBounds(300 + _insets.left, 145 + _insets.top, size.width, 25);
        
        _passField = new JPasswordField(fieldSize);
        _passField.addActionListener(_listener);
        _panel.add(_passField);
        size = _passField.getPreferredSize();
        _passField.setBounds(300 + _insets.left, 215 + _insets.top, size.width, 25);
        
        //BUTTONS
        _login = new JButton("Login");
        _register = new JButton("Register");
        //DON'T FORGET TO ADD THE MOUSE CLICK LISTENER TO EVERY BUTTON YOU CREATE
        _login.addActionListener(_listener); 
        _register.addActionListener(_listener);
        
        _panel.add(_login);
        _panel.add(_register);
        
        size = _login.getPreferredSize();
        _login.setBounds(360 + _insets.left, 300 + _insets.top, size.width,
                size.height);
        size = _register.getPreferredSize();
        _register.setBounds(352 + _insets.left, 350 + _insets.top, size.width,
                size.height);
        
        _panel.setBackground(Color.RED.darker()); //dark red background

        add(_panel); //REMEMBER TO add(_panel) so that the components will be displayed
        
        
        //Remember:
        //if you use insets.right, the component will go to the left
        //insets.left, the component will go to the right 
        //insets.top, the component will go to the bottom
        //insets.bottom, the component will go to the top
        
        //Example: if you want to position a label like titleLabel... use
        //Dimension size = instructionLabel.getPreferredSize();
        //THEN
        //titleLabel.setbounds(Horizontal Position, Vertical Position, size.width, size.height)
        //Remember to keep test running to see if the component is in the right spot
        
        //This works for JLabels, JButtons, JTextFields, JPasswordFields, Images etc.
    }
    
    /**
     * 
     * @param email
     * @param password
     * @return 
     */
    private boolean userExists(String email, String password)
    {   
        //uses the RegisteredUsers class
        //iterate through registeredAthletes and registeredTrainers
        boolean toReturn = false; //starts off as false because we could find a match yet
        ArrayList<Athlete> regAthletes = _rUsers.getRegisteredAthletes();
        ArrayList<Trainer> regTrainers = _rUsers.getRegisteredTrainers();
        String athletesEmail;
        String athletesPass;
        String trainersEmail;
        String trainersPass;
        
        //iterate through athletes first to check if email and password exists
        //in the system
        for (int a = 0; a < regAthletes.size(); a++)
        {
            athletesEmail = regAthletes.get(a).getEmail();
            athletesPass = regAthletes.get(a).getPassword();
            if (email.equals(athletesEmail))
            {
                //if email exists then check if password exists in the same Athlete object
                if(password.equals(athletesPass))
                {
                    toReturn = true;
                }
            }
        }
        
        if (!toReturn) //if toReturn is still false
        {
            //now iterate through the trainer's array
            for (int t = 0; t < regTrainers.size(); t++)
            {
                trainersEmail = regTrainers.get(t).getEmail();
                trainersPass = regTrainers.get(t).getPassword();
                if (email.equals(trainersEmail))
                {
                    //if email exists then check if password exists in the same Trainer object
                    if(password.equals(trainersPass))
                    {
                        toReturn = true;
                    }
                }
            }
        }
        return toReturn;
    }
    
    /**
     * Puts in the components
     * @param formType 
     */
    private void formComponents(FormType formType)
    {
        int fieldSize = 20;
        //creates components for forms
        boolean register = formType == FormType.REGISTER;
        boolean injuryReport = formType == FormType.INJURY_REPORT;
        boolean plan = formType == FormType.CREATE_PLAN;
        Dimension size;
        
        if (register)
        {
            //When registering, once the user clicks on the submit button, the
            //information will be put in the RegisteredUsers class
            RegisterForm rf = new RegisterForm();
            
            //LABELS
            //registration label
            _label = new JLabel("Registration");
            _label.setFont(new Font("Arial", Font.BOLD, 20));
            _label.setForeground(Color.WHITE);
            _panel.add(_label);
            size = _label.getPreferredSize();
            _label.setBounds(10 + _insets.right, 5 + _insets.top,
                     size.width, size.height);
            
            //Instruction Label
            _label = new JLabel("Please fill in all of the fields and click Submit when you're done.");
            _label.setFont(new Font("Arial", Font.BOLD, 14));
            _label.setForeground(Color.WHITE);
            _panel.add(_label);
            size = _label.getPreferredSize();
            _label.setBounds(10 + _insets.right, 30 + _insets.top, size.width,
                    size.height);
            
            //UserType label
            _label = new JLabel("Are you an Athlete or a Trainer? ");
            _label.setFont(new Font("Arial", Font.BOLD, 14));
            _label.setForeground(Color.WHITE);
            _panel.add(_label);
            size = _label.getPreferredSize();
            _label.setBounds(140 + _insets.left, 100 + _insets.top, size.width, size.height);
            
            //checkbox question. Are you Trainer or Athlete?
            _selectUserType = new JComboBox<>();
            _selectUserType.addItem("Athlete");
            _selectUserType.addItem("Trainer");
            _panel.add(_selectUserType);
            size = _selectUserType.getPreferredSize();
            _selectUserType.setBounds(380 + _insets.left, 95 + _insets.top, size.width,
                    size.height);
            
            //Question Labels
            _label = new JLabel("Enter your first name: ");
            _label.setFont(new Font("Arial", Font.BOLD, 14));
            _label.setForeground(Color.WHITE);
            _panel.add(_label);
            size = _label.getPreferredSize();
            _label.setBounds(140 + _insets.left, 150 + _insets.top, size.width,
                size.height);
            
            _label = new JLabel("Enter your last name: ");
            _label.setFont(new Font("Arial", Font.BOLD, 14));
            _label.setForeground(Color.WHITE);
            _panel.add(_label);
            size = _label.getPreferredSize();
            _label.setBounds(140 + _insets.left, 220 + _insets.top, size.width,
                size.height);
            
            _label = new JLabel("Enter Email: ");
            _label.setFont(new Font("Arial", Font.BOLD, 14));
            _label.setForeground(Color.WHITE);
            _panel.add(_label);
            size = _label.getPreferredSize();
            _label.setBounds(140 + _insets.left, 290 + _insets.top, size.width,
                    size.height);
            
            _label = new JLabel("Enter Password: ");
            _label.setFont(new Font("Arial", Font.BOLD, 14));
            _label.setForeground(Color.WHITE);
            _panel.add(_label);
            size = _label.getPreferredSize();
            _label.setBounds(140 + _insets.left, 360 + _insets.top, size.width, 
                    size.height);
            
            //Question TextFields below
            _firstNameField = new JTextField(fieldSize);
            _panel.add(_firstNameField);
            size = _firstNameField.getPreferredSize();
            _firstNameField.setBounds(300 + _insets.left, 145 + _insets.top, size.width, 25);
            
            _lastNameField = new JTextField(fieldSize);
            _panel.add(_lastNameField);
            size = _lastNameField.getPreferredSize();
            _lastNameField.setBounds(300 + _insets.left, 215 + _insets.top, size.width, 25);
            
            _emailField = new JTextField(fieldSize);
            _panel.add(_emailField);
            size = _emailField.getPreferredSize();
            _emailField.setBounds(300 + _insets.left, 285 + _insets.top, size.width, 25);
            
            _passField = new JPasswordField(fieldSize);
            _panel.add(_passField);
            size = _passField.getPreferredSize();
            _passField.setBounds(300 + _insets.left, 355 + _insets.top, size.width, 25);
            
            //JButtons below
            _submitRegister = new JButton("Submit");
            _goBackRegister = new JButton("Go Back");
            _submitRegister.addActionListener(_listener);
            _goBackRegister.addActionListener(_listener);

            _panel.add(_submitRegister);
            _panel.add(_goBackRegister);

            size = _submitRegister.getPreferredSize();
            _submitRegister.setBounds(300 + _insets.left, 420 + _insets.top, size.width,
                    size.height);
            size = _goBackRegister.getPreferredSize();
            _goBackRegister.setBounds(400 + _insets.left, 420 + _insets.top, size.width,
                    size.height);

            //System.out.println(_email); 
        }
        else if (injuryReport)
        {
            //uses InjurtReportForm
            InjuryReportForm inf = new InjuryReportForm();
            JLabel injuryReportTitle = new JLabel("Report an Injury");
            injuryReportTitle.setFont(new Font("Arial", Font.BOLD, 20));
            _panel.add(injuryReportTitle);
            
            _insets = _panel.getInsets();
            size = injuryReportTitle.getPreferredSize();
            
            injuryReportTitle.setBounds(10 + _insets.right, 5 + _insets.top,
                     size.width, size.height);
            
            //InjuryReportData data = new InjuryReportData();
            //data._firstName = _email;
            
            //InMemoryStorage storage = new InMemoryStorage();
            //storage.createInjuryReport(data);
            

        }
        else if(plan)
        {
            //uses Create Plan Form
            PlanForm cp = new PlanForm();
            JLabel createPlanTitle = new JLabel("Create a Plan");
            createPlanTitle.setFont(new Font("Arial", Font.BOLD, 20));
            _panel.add(createPlanTitle);
            
            size = createPlanTitle.getPreferredSize();
            
            createPlanTitle.setBounds(10 + _insets.right, 5 + _insets.top,
                     size.width, size.height);
            
        }
    }
    
    //more methods may be created soon
    
    /**
    * This class listens to the user's clicks in the application
    */    
    public class ClickListener implements ActionListener{
        
        @Override
        /**
         * I'LL TEACH YOU HOW THE MOUSE CLICKING SCANNING WORKS
         */
        public void actionPerformed(ActionEvent event)
        {
            //For LOGIN
            if (event.getSource() == _login) //If the _login JButton was clicked
            {
                //get input from user 
                //USE MAP INSTEAD LATER
                String emailInput = _emailField.getText();
                String passwordInput = _passField.getText();
                
                System.out.println(emailInput);
                System.out.println(passwordInput);
                
                //check if user is registered in the system
                boolean userExists = userExists(emailInput, passwordInput);
                //if user IS in the system, check their userType
                
                if(userExists)
                {
                    //THIS IS HOW YOU CHANGE THE SCREEN INTO A COMPLETELY DIFFERENT SCREEN
                    
                    System.out.println("Exists!"); //delete later
                    //Revalidate and Repaint the screen
                    _panel.removeAll(); //remove all of the components
                    //add new components here
                    //it DEPENDS on the userType
                    
                    //use revalidate and repaint to add all of the NEW components in
                    _panel.revalidate();
                    _panel.repaint();
                }
                else
                {
                    JLabel userNoExist = new JLabel("Email or Password are incorrect. "
                            + "Please try again");
                    //this is how you change the color of the font
                    userNoExist.setForeground(Color.YELLOW); 
                    _panel.add(userNoExist);
                    Dimension size = userNoExist.getPreferredSize();
                    
                    userNoExist.setBounds(10 + _insets.right, 100 + _insets.top,
                        size.width, size.height); 
                }
            }
            //for registering
            else if(event.getSource() == _register)
            {
                //revalidate and repaint to change screen
                _panel.removeAll();
                //add registerform components here
                formComponents(FormType.REGISTER);
                _panel.revalidate();
                _panel.repaint();
            }
            else if (event.getSource() == _submitRegister)
            {
                //FIRST check if user filled in all of the parts
                String userType = (String) _selectUserType.getSelectedItem();
                String firstNameInput = _firstNameField.getText();
                String lastNameInput = _lastNameField.getText();
                String emailInput = _emailField.getText();
                String passInput = _passField.getText();
                boolean aTextFieldIsEmpty = firstNameInput.isEmpty() || lastNameInput.isEmpty()
                        || emailInput.isEmpty() || passInput.isEmpty();
                
                if (aTextFieldIsEmpty)
                {
                    JLabel inputNotValid = new JLabel("One or more fields are empty."
                            + " Please fill them in.");
                    inputNotValid.setForeground(Color.YELLOW);
                    _panel.add(inputNotValid);
                    
                    Dimension size = inputNotValid.getPreferredSize();
                    
                    inputNotValid.setBounds(10 + _insets.right, 50 + _insets.top,
                        size.width, size.height); 
                    
                }
                else //The text fields are NOT empty
                {
                    if (userType.equals("Athlete")) //If user registers as Athlete
                    {
                        
                        
                    }
                    else if (userType.equals("Trainer")) //If user registers as Trainer
                    {
                    
                    }
                
                    _panel.removeAll();
                    loginComponents(); //goes back to login screen
                    //create a JLabel here saying Registration Successful!
                    JLabel successful = new JLabel("Registration Successful!");
                    successful.setForeground(Color.YELLOW);
                    _panel.add(successful);
                    
                    _panel.revalidate();
                    _panel.repaint();
                }
                
            }
            else if (event.getSource() == _goBackRegister)
            {
                _panel.removeAll();
                loginComponents();
                _panel.revalidate();
                _panel.repaint();
            }
        }
    }
}
