/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.JFrame;

/**
 * @author Elena Ngo
 * @author Tim Yarosh
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A
 */
public class AthleteRehabApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JFrame frame = new AppFrame();
        frame.setTitle("Athlete Rehab Application");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true); //visibility of the frame. True makes it visible

    }

}
