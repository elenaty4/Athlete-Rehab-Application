/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.util.ArrayList;

/**
 * @author Elena Ngo
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A
 */
public class Athlete extends User {
    
    private ArrayList<InjuryReport> _listOfTheirReports;
    private Plan _theirPlan;
    
    //boolean methods
    public boolean hasReport()
    {
        return true;
    }
    
    public boolean hasPlan()
    {
        return true;
    }
    
    //getters
    @Override
    public String getFullName()
    {
        return super.getFullName();
    }
    
    @Override
    public String getFirstName()
    {
        return super.getFirstName();
    }
    
    @Override
    public String getLastName()
    {
        return super.getLastName();
    }
    
    @Override
    public String getPassword()
    {
        return super.getPassword();
    }
    
    public ArrayList<InjuryReport> getReportList()
    {
        return _listOfTheirReports;
    }
    
    public Plan getTheirPlan()
    {
        return _theirPlan;
    }
    
    //toString method
    @Override
    /**
     * 
     */
    public String toString()
    {
        return null;        
    }
    
}
