/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.*;
import java.util.ArrayList;
import java.util.Map;


/**
 * @author Elena Ngo
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A 
 */
public class AppFrame extends JFrame {
    
final private int FRAME_WIDTH = 800; //numbers are subject to change
    final private int FRAME_HEIGHT= 600;
    
    private JPanel _panel;
    private JButton _login;
    private JButton _register;
    
    private JTextField _emailField;
    private JPasswordField _passField;
    
    private FormFactory _formF;
    private RegisteredUsers _rUsers;
    
    String _emailInput;
    String _passwordInput;
    
    private ActionListener _listener; //listens to what the mouse clicks
    
    public AppFrame()
    {
        //will call loginComponent
        //and then AthleteMenu Component and so on
        loginComponent();
        setSize(FRAME_WIDTH, FRAME_HEIGHT);
    }
    
    private void loginComponent() //private method because it is only used in this class
    {
        //USE DIMENSIONS INSTEAD OF BORDERLAYOUT TO POSITION PANELS
        int fieldSize = 20;
        //starts off with a LOGIN SCREEN
        _rUsers = new RegisteredUsers();
        _formF = new FormFactory();
        _listener = new ClickListener();
        _panel = new JPanel();
        
        //CREATE LOGIN PAGE
        //HOW TO PUT COMPONENTS IN A FIXED POSITION
        _panel.setLayout(null); //panel shouldn't have a layout for this
        

        //Labels
        JLabel titleLabel = new JLabel("Welcome to the Athlete Rehab Application");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20)); //changing the size of the font
        JLabel instructionLabel = new JLabel("Please enter your email and password below.");
        instructionLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        JLabel emailLabel = new JLabel("Email: ");
        emailLabel.setFont(new Font("Arial", Font.BOLD, 16));
        JLabel passwordLabel = new JLabel("Password: ");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 16));
        
        //TextFields
        _emailField = new JTextField(fieldSize);
        _passField = new JPasswordField(fieldSize);
        _emailField.addActionListener(_listener);
        _passField.addActionListener(_listener);
        
        //buttons
        _login = new JButton("Login");
        _register = new JButton("Register");
        _login.addActionListener(_listener);
        _register.addActionListener(_listener);
        
        //putting them all in the _panel
        _panel.add(titleLabel);
        _panel.add(instructionLabel);
        _panel.add(emailLabel);
        _panel.add(passwordLabel);
        _panel.add(_emailField);
        _panel.add(_passField);
        _panel.add(_login);
        _panel.add(_register);

        Insets insets = _panel.getInsets();
        Dimension size = titleLabel.getPreferredSize();
        //Setting the position. 
        //setbounds (Horizontal <Left or Right>, Vertical <top or bottom>, width, height)
        titleLabel.setBounds(10 + insets.right, 5 + insets.top,
                     size.width, size.height); 
        size = instructionLabel.getPreferredSize();
        instructionLabel.setBounds(10 + insets.right, 40 + insets.top, size.width,
                size.height);
        size = emailLabel.getPreferredSize();
        emailLabel.setBounds(200 + insets.left, 150 + insets.top, size.width,
                size.height);
        size = passwordLabel.getPreferredSize();
        passwordLabel.setBounds(200 + insets.left, 220 + insets.top, size.width,
                size.height);
        
        size = _emailField.getPreferredSize();
        _emailField.setBounds(300 + insets.left, 145 + insets.top, size.width, 25);
        size = _passField.getPreferredSize();
        _passField.setBounds(300 + insets.left, 215 + insets.top, size.width, 25);
        
        size = _login.getPreferredSize();
        _login.setBounds(360 + insets.left, 300 + insets.top, size.width,
                size.height);
        size = _register.getPreferredSize();
        _register.setBounds(352 + insets.left, 350 + insets.top, size.width,
                size.height);

        add(_panel);
        
        //Get text input from the user.
        
    }
    
    private boolean userExists(String email, String password)
    {
        //uses the RegisteredUsers class
        //iterate through registeredAthletes and registeredTrainers
        boolean toReturn = false; //starts off as false because we could find a match yet
        ArrayList<Athlete> regAthletes = _rUsers.getRegisteredAthletes();
        ArrayList<Trainer> regTrainers = _rUsers.getRegisteredTrainers();
        
        //iterate through athletes first to check if email and password exists
        //in the system
        for (int a = 0; a < regAthletes.size(); a++)
        {
            String athletesEmail = regAthletes.get(a).getEmail();
            String athletesPass = regAthletes.get(a).getPassword();
            if (email.equals(athletesEmail))
            {
                //if email exists then check if password exists in the same Athlete object
                if(password.equals(athletesPass))
                {
                    toReturn = true;
                }
            }
        }
        
        if (!toReturn) //if toReturn is still false
        {
            //now iterate through the trainer's array
            for (int t = 0; t < regTrainers.size(); t++)
            {
                String trainersEmail = regTrainers.get(t).getEmail();
                String trainersPass = regTrainers.get(t).getPassword();
                if (email.equals(trainersEmail))
                {
                    //if email exists then check if password exists in the same Trainer object
                    if(password.equals(trainersPass))
                    {
                        toReturn = true;
                    }
                }
            }
        }
        return toReturn;
    }
    
    private void registerComponents()
    {
        //when user wants to register, this method is called.
        //this method will use the RegisterForm class
    }
    
    //more methods may be created soon
    
    /**
    * This class listens to the user's clicks in the application
    */    
    public class ClickListener implements ActionListener{
        
        @Override
        public void actionPerformed(ActionEvent event)
        {
            //For LOGIN
            if (event.getSource() == _login)
            {
                //get input from user 
                //USE MAP INSTEAD LATER
                String emailInput = _emailField.getText();
                String passwordInput = _passField.getText();
                
                System.out.println(emailInput);
                System.out.println(passwordInput);
                
                //check if user is registered in the system
                boolean userExists = userExists(emailInput, passwordInput);
                //if user IS in the system, check their userType
                
                
                if(userExists)
                {
                    System.out.println("Exists!"); //delete later
                    //Revalidate and Repaint the screen
                    _panel.removeAll();
                    //add new components here
                    //it DEPENDS on the userType
                    
                    
                    registerComponents();
                    _panel.revalidate();
                    _panel.repaint();
                }
                else
                {
                    JLabel userNoExist = new JLabel("Email or Password are incorrect. "
                            + "Please try again");
                    userNoExist.setForeground(Color.red);
                    _panel.add(userNoExist);
                    Insets insets = _panel.getInsets();
                    Dimension size = userNoExist.getPreferredSize();
                    
                    userNoExist.setBounds(10 + insets.right, 100 + insets.top,
                        size.width, size.height); 
                }
            }
            //for registering
            else if(event.getSource() == _register)
            {
                //revalidate and repaint to change screen
                _panel.removeAll();
                //add new components here
                _panel.revalidate();
                _panel.repaint();
            }
        }
    }
}
