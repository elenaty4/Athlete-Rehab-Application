/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

/**
 * @author Tim Yarosh
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A
 */
public class InjuryReport {

    private static String _dayInjurySubmitted;
    private static String _timeInjurySubmitted;
    private static String _dayInjuryOccured; //the month, day and hour. The String type may change
    private static String _injuryDuration; //the String type may change
    private static String _description;
    private static String _intensity;

    public InjuryReport(String day_submitted, String time_submitted,
            String day_occured, String duration, String description,
            String intensity) {

        _dayInjurySubmitted = day_submitted;
        _timeInjurySubmitted = time_submitted;
        _dayInjuryOccured = day_occured;
        _injuryDuration = duration;
        _description = description;
        _intensity = intensity;
    }

    //accessors
    public String getDayInjurySubmitted() {
        return _dayInjurySubmitted;
    }

    public String getTimeInjurySubmitted() {
        return _timeInjurySubmitted;
    }

    public String getDayInjuryOccured() {
        return _dayInjuryOccured;
    }

    public String getInjuryDuration() {
        return _injuryDuration;
    }

    public String getInjuryDescription() {
        return _description;
    }

    public String getInjuryIntensity() {
        return _intensity;
    }

    //toString method
    @Override
    public String toString() {
        String toReturn = "Day injury submitted: " + _dayInjurySubmitted + "\n";
        toReturn += "Time injury submitted: "+_timeInjurySubmitted+"\n";
        toReturn += "Day injury occured: "+_dayInjuryOccured+"\n";
        toReturn += "Injury duration: "+_injuryDuration+"\n";
        toReturn += "Injury description: "+_description+"\n";
        toReturn += "Injury intensity: "+_intensity;
        
        return toReturn;
    }
}
