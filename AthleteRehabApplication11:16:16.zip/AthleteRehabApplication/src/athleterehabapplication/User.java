/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

/**
 * @author Elena Ngo
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A
 */
public class User {
    private String _fullName;
    private String _firstName;
    private String _lastName;
    private String _password;
    
    //getters
    public String getFullName()
    {
        return _fullName;
    }
    
    public String getFirstName()
    {
        return _firstName;
    }
    
    public String getLastName()
    {
        return _lastName;
    }
    
    public String getPassword()
    {
        return _password;
    }
    
    
    //toString method
    //returns a string representation of the object
    @Override
    /**
     * 
     */
    public String toString()
    {
        return null;
    }
}
