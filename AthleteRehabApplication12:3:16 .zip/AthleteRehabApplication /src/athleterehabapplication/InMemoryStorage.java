/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.util.ArrayList;

/**
 * @author Tim Yarosh
 * @version 1.0
 * @date 11/26/16
 * @section CS275.A
 */
public class InMemoryStorage implements Persistence {

    private static ArrayList<InjuryReport> _injuryReports;
    private static ArrayList<User> _users;
    private static ArrayList<Plan> _plans;

    public InMemoryStorage() {
        _injuryReports = new ArrayList<>();
        _users = new ArrayList<>();
        _plans = new ArrayList<>();
    }

    @Override
    public void register(User user) {
        _users.add(user);
    }

    @Override
    public User findUser(String identifier) {
        for (User u : _users) {
            if (u.getEmail().equals(identifier)) {
                return u;
            }
        }
        return null;
    }

    @Override
    public void createInjuryReport(InjuryReportData data) {
        _injuryReports.add(new InjuryReport(data));
    }

    @Override
    public ArrayList<InjuryReport> findInjuryReports(String identifier) {

        ArrayList<InjuryReport> report = new ArrayList<>();

        for (InjuryReport r : _injuryReports) {
            report.add(r);
        }
        return report;
    }

    @Override
    public ArrayList<InjuryReport> getAllInjuryReports() {
        return _injuryReports;
    }

    @Override
    public void createPlan(PlanData data) {
        _plans.add(new Plan(data));
    }

    @Override
    public ArrayList<Plan> findPlans(String identifier) {
        
        ArrayList<Plan> plan = new ArrayList<>();
        
        for(Plan p : _plans){
            plan.add(p);
        }
        return plan;
    }

    @Override
    public ArrayList<Plan> getAllPlans() {
        return _plans;
    }

}
