/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * @author Tim Yarosh
 * @version 1.0
 * @date 11/28/16
 * @section CS275.A
 */
public class PlanForm extends Form {

    private Plan _plan;
    private ArrayList<String> _questions;

    public PlanForm() {
        _questions = getQuestions();
    }

    public void createPlan() {
        PlanData data = new PlanData();

        data._description = "description"; //needs to be pulled from Form
        data._estimatedDuration = "4 weeks"; //needs to be pulled from Form
        data._identifier = "first name + last name"; //needs to be pulled from Form
        data._instructions = "instructions"; //need to be pulled from Form

        InMemoryStorage storage = new InMemoryStorage();
        storage.createPlan(data);
    }

    public ArrayList<Plan> findPlans(String identifier) {
        
        InMemoryStorage storage = new InMemoryStorage();
        
        return storage.findPlans(identifier);

    }
    
    public ArrayList<Plan> getAllPlans() {
        
        InMemoryStorage storage = new InMemoryStorage();
        
        return storage.getAllPlans();
    }

    //getter
    public static ArrayList<String> getQuestions() {
        return Form.getQuestions();
    }

    //toString
    @Override
    public String toString() {
        String toReturn = Arrays.toString(_questions.toArray());
        toReturn += "\n"+_plan;

        return toReturn;
    }
}
