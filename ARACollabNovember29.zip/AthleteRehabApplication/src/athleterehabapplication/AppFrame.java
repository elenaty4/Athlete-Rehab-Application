/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.*;
import java.util.ArrayList;


/**
 * @author Elena Ngo
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A 
 */
public class AppFrame extends JFrame {
    
    //These ints hold the default size of the frame
    final private int FRAME_WIDTH = 800; //numbers are subject to change
    final private int FRAME_HEIGHT= 600;
    
    
    private JPanel _panel; //the panel holds all of the components of the frame
    private JButton _login; //The login button that is clickable
    private JButton _register; //The register button that is clickable
    
    //User will type in their email and password in these fields. 
    //The words that they type in will be read once they click on the login button
    //Note that JPasswordField is ALSO a textField but when the user types something
    //in there the words are replaced by dots for security
    private JTextField _emailField;
    private JPasswordField _passField; 
    
    private FormFactory _formF;
    
    private RegisteredUsers _rUsers; //holds the list of users who are registered.
    
    private ActionListener _listener; //listens to what the mouse clicks. It's like
    //a scanner for the mouse clicking
    
    
    //THE METHODS BELOW CONSIST OF ADDING COMPONENTS TO THE FRAME. THEY ARE SEPARATED
    //INTO DIFFERENT PARTS:
    //loginComponents() adds the GUI components for the Login screen
    //formComponents() adds the Register Screen components, Injury Report Form components,
    //and the creat Plan form components
    
    //The ClickListener class in this AppFrame class is only there to scan what
    //the mouse clicked on and change the screen from it
    
    /**
     * 
     */
    public AppFrame()
    {
        //will call loginComponent
        //and then AthleteMenu Component and so on
        loginComponents();
        setSize(FRAME_WIDTH, FRAME_HEIGHT);
    }
    
    /**
     * 
     */
    private void loginComponents() //private method because it is only used in this class
    {
        //USE DIMENSIONS INSTEAD OF BORDERLAYOUT TO POSITION PANELS
        int fieldSize = 20;
        //starts off with a LOGIN SCREEN
        _rUsers = new RegisteredUsers();
        _formF = new FormFactory();
        _listener = new ClickListener();
        _panel = new JPanel();
        
        //CREATE LOGIN PAGE
        _panel.setLayout(null); //panel shouldn't have a layout for exact positioning

        //Labels
        JLabel titleLabel = new JLabel("Welcome to the Athlete Rehab Application");
        
        //THIS IS HOW YOU CHANGE THE SIZE OF THE LABEL
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        
        JLabel instructionLabel = new JLabel("Please enter your email and password below.");
        instructionLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        JLabel emailLabel = new JLabel("Email: ");
        emailLabel.setFont(new Font("Arial", Font.BOLD, 16));
        JLabel passwordLabel = new JLabel("Password: ");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 16));
        
        //TextFields
        _emailField = new JTextField(fieldSize);
        _passField = new JPasswordField(fieldSize);
        _emailField.addActionListener(_listener);
        _passField.addActionListener(_listener);
        
        //buttons
        _login = new JButton("Login");
        _register = new JButton("Register");
        //DON'T FORGET TO ADD THE MOUSE CLICK LISTENER TO EVERY BUTTON YOU CREATE
        _login.addActionListener(_listener); 
        _register.addActionListener(_listener);
        
        //putting them all in the _panel
        _panel.add(titleLabel);
        _panel.add(instructionLabel);
        _panel.add(emailLabel);
        _panel.add(passwordLabel);
        _panel.add(_emailField);
        _panel.add(_passField);
        _panel.add(_login);
        _panel.add(_register);

        //THE CODE BELOW WILL SHOW YOU HOW TO PUT THE COMPONENTS IN AN EXACT POSITION
        //OF THE FRAME WITHOUT USING ANY LAYOUTS
        Insets insets = _panel.getInsets();
        
        //Remember:
        //if you use insets.right, the component will go to the left
        //insets.left, the component will go to the right 
        //insets.top, the component will go to the bottom
        //insets.bottom, the component will go to the top
        
        //Example: if you want to position a label like titleLabel... use
        //Dimension size = instructionLabel.getPreferredSize();
        //THEN
        //titleLabel.setbounds(Horizontal Position, Vertical Position, size.width, size.height)
        //Remember to keep test running to see if the component is in the right spot
        
        //This works for JLabels, JButtons, JTextFields, JPasswordFields, Images etc.
        Dimension size = titleLabel.getPreferredSize();
        titleLabel.setBounds(10 + insets.right, 5 + insets.top,
                     size.width, size.height); 
        size = instructionLabel.getPreferredSize();
        instructionLabel.setBounds(10 + insets.right, 40 + insets.top, size.width,
                size.height);
        size = emailLabel.getPreferredSize();
        emailLabel.setBounds(200 + insets.left, 150 + insets.top, size.width,
                size.height);
        size = passwordLabel.getPreferredSize();
        passwordLabel.setBounds(200 + insets.left, 220 + insets.top, size.width,
                size.height);
        
        size = _emailField.getPreferredSize();
        _emailField.setBounds(300 + insets.left, 145 + insets.top, size.width, 25);
        size = _passField.getPreferredSize();
        _passField.setBounds(300 + insets.left, 215 + insets.top, size.width, 25);
        
        size = _login.getPreferredSize();
        _login.setBounds(360 + insets.left, 300 + insets.top, size.width,
                size.height);
        size = _register.getPreferredSize();
        _register.setBounds(352 + insets.left, 350 + insets.top, size.width,
                size.height);

        add(_panel); //REMEMBER TO add(_panel) so that the components will be displayed
    }
    
    /**
     * 
     * @param email
     * @param password
     * @return 
     */
    private boolean userExists(String email, String password)
    {   
        //uses the RegisteredUsers class
        //iterate through registeredAthletes and registeredTrainers
        boolean toReturn = false; //starts off as false because we could find a match yet
        ArrayList<Athlete> regAthletes = _rUsers.getRegisteredAthletes();
        ArrayList<Trainer> regTrainers = _rUsers.getRegisteredTrainers();
        
        //iterate through athletes first to check if email and password exists
        //in the system
        for (int a = 0; a < regAthletes.size(); a++)
        {
            String athletesEmail = regAthletes.get(a).getEmail();
            String athletesPass = regAthletes.get(a).getPassword();
            if (email.equals(athletesEmail))
            {
                //if email exists then check if password exists in the same Athlete object
                if(password.equals(athletesPass))
                {
                    toReturn = true;
                }
            }
        }
        
        if (!toReturn) //if toReturn is still false
        {
            //now iterate through the trainer's array
            for (int t = 0; t < regTrainers.size(); t++)
            {
                String trainersEmail = regTrainers.get(t).getEmail();
                String trainersPass = regTrainers.get(t).getPassword();
                if (email.equals(trainersEmail))
                {
                    //if email exists then check if password exists in the same Trainer object
                    if(password.equals(trainersPass))
                    {
                        toReturn = true;
                    }
                }
            }
        }
        return toReturn;
    }
    
    /**
     * Puts in the components
     * @param formType 
     */
    private void formComponents(FormType formType)
    {
        //creates components for forms
        boolean register = formType == FormType.REGISTER;
        boolean injuryReport = formType == FormType.INJURY_REPORT;
        boolean plan = formType == FormType.CREATE_PLAN;
        
        if (register)
        {
            //When registering, once the user clicks on the submit button, the
            //information will be put in the RegisteredUsers class
            RegisterForm rf = new RegisterForm();
            
            JLabel registerTitle = new JLabel("Registration");
            registerTitle.setFont(new Font("Arial", Font.BOLD, 20));
            _panel.add(registerTitle);
        
            Insets insets = _panel.getInsets();
            Dimension size = registerTitle.getPreferredSize();
        
            registerTitle.setBounds(10 + insets.right, 5 + insets.top,
                     size.width, size.height);
        }
        else if (injuryReport)
        {
            //uses InjurtReportForm

        }
        else if(plan)
        {
            //uses Create Plan Form
        }
    }
    
    //more methods may be created soon
    
    /**
    * This class listens to the user's clicks in the application
    */    
    public class ClickListener implements ActionListener{
        
        @Override
        /**
         * I'LL TEACH YOU HOW THE MOUSE CLICKING SCANNING WORKS
         */
        public void actionPerformed(ActionEvent event)
        {
            //For LOGIN
            if (event.getSource() == _login) //If the _login JButton was clicked
            {
                //get input from user 
                //USE MAP INSTEAD LATER
                String emailInput = _emailField.getText();
                String passwordInput = _passField.getText();
                
                System.out.println(emailInput);
                System.out.println(passwordInput);
                
                //check if user is registered in the system
                boolean userExists = userExists(emailInput, passwordInput);
                //if user IS in the system, check their userType
                
                if(userExists)
                {
                    //THIS IS HOW YOU CHANGE THE SCREEN INTO A COMPLETELY DIFFERENT SCREEN
                    
                    System.out.println("Exists!"); //delete later
                    //Revalidate and Repaint the screen
                    _panel.removeAll(); //remove all of the components
                    //add new components here
                    //it DEPENDS on the userType
                    
                    //use revalidate and repaint to add all of the NEW components in
                    _panel.revalidate();
                    _panel.repaint();
                }
                else
                {
                    JLabel userNoExist = new JLabel("Email or Password are incorrect. "
                            + "Please try again");
                    //this is how you change the color of the font
                    userNoExist.setForeground(Color.red); 
                    _panel.add(userNoExist);
                    Insets insets = _panel.getInsets();
                    Dimension size = userNoExist.getPreferredSize();
                    
                    userNoExist.setBounds(10 + insets.right, 100 + insets.top,
                        size.width, size.height); 
                }
            }
            //for registering
            else if(event.getSource() == _register)
            {
                //revalidate and repaint to change screen
                _panel.removeAll();
                //add new components here
                formComponents(FormType.REGISTER);
                _panel.revalidate();
                _panel.repaint();
            }
        }
    }
}
