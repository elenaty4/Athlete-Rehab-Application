/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.util.ArrayList;

/**
 * @author Tim Yarosh
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A
 */
public class PlanForm extends Form {

    private Plan _plan;

    public PlanForm() {
        //constructor will put the questions the form has into the ArrayList of questions
    }

    public Plan createPlan() {
        return null;
    }

    //getter
    public static ArrayList<String> getQuestions() {
        return Form.getQuestions();
    }

    //toString
    @Override
    public String toString() {
        return null;
    }
}
