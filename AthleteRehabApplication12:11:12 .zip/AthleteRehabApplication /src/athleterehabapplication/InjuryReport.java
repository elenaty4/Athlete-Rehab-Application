/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * @author Tim Yarosh
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A
 */
public class InjuryReport {

    private LocalDate _dayInjurySubmitted;
    private LocalTime _timeInjurySubmitted;
    private String _description;
    private String _dayInjuryOccured;
    private String _injuryDuration;
    private String _intensity;
    private String _identifier;
    private String _firstName;
    private String _lastName;

    public InjuryReport(InjuryReportData data) {

        _identifier = data._identifier;
        _dayInjurySubmitted = LocalDate.now();
        _timeInjurySubmitted = LocalTime.now();
        _description = data._description;
        _dayInjuryOccured = data._dayInjuryOccured;
        _injuryDuration = data._injuryDuration;
        _intensity = data._intensity;
        _firstName = data._firstName;
        _lastName = data._lastName;
    }

    //accessors
    public String getFirstName() {
        return _firstName;
    }

    public String getLastName() {
        return _lastName;
    }

    public String getIndentifier() {
        return _identifier;
    }

    public String getDayInjurySubmitted() {
        return _dayInjurySubmitted.toString();
    }

    public String getTimeInjurySubmitted() {
        return _timeInjurySubmitted.toString();
    }

    public String getDayInjuryOccured() {
        return _dayInjuryOccured;
    }

    public String getInjuryDuration() {
        return _injuryDuration;
    }

    public String getInjuryIntensity() {
        return _intensity;
    }

    public String getDescription() {
        return _description;
    }

    //toString method
    @Override
    public String toString() {
        String toReturn = "Specific identifier: " + _identifier + "\n";
        toReturn += "Name: " + _firstName + " " + _lastName + "\n";
        toReturn += "Day injury submitted: " + _dayInjurySubmitted + "\n";
        toReturn += "Time injury submitted: " + _timeInjurySubmitted + "\n";
        toReturn += "Description: " + _description + "\n";
        toReturn += "Day injury occured: " + _dayInjuryOccured + "\n";
        toReturn += "Injury duration: " + _injuryDuration + "\n";
        toReturn += "Injury intensity: " + _intensity;

        return toReturn;
    }
}
