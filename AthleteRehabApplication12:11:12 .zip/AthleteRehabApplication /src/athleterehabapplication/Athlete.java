/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.util.ArrayList;

/**
 * @author Elena Ngo
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A
 */
public class Athlete extends User {
    
    private ArrayList<InjuryReport> _listOfTheirReports;
    private Plan _theirPlan;
    
    public Athlete()
    {
        super._userType = UserType.ATHLETE;
    }
    
    //boolean methods
    public boolean hasReport()
    {
        //check if the array is empty
        boolean toReturn = false;
        if(!_listOfTheirReports.isEmpty()) //if not empty
        {
            toReturn = true;
        }
        return toReturn;
    }
    
    public boolean hasPlan()
    {
        //if Plan exists. PLAN MUST HAVE A BOOLEAN EXIST() METHOD
        boolean toReturn = false;
        return toReturn;
    }
    
    @Override
    public String getFirstName()
    {
        return super.getFirstName();
    }
    
    @Override
    public String getLastName()
    {
        return super.getLastName();
    }
    
    @Override
    public String getEmail(){
        return super.getEmail();
    }
    
    @Override
    public String getPassword()
    {
        return super.getPassword();
    }
    
    public void addReport(InjuryReport report){
        _listOfTheirReports.add(report);
        
    }
    
    public ArrayList<InjuryReport> getReportList()
    {
        return _listOfTheirReports;
    }
    
    public Plan getTheirPlan()
    {
        return _theirPlan;
    }
    
    @Override
    public String toString()
    {
        String toReturn = "User type: " + _userType + "\n";
        toReturn += "First name: " + getFirstName() + "\n";
        toReturn += "Last name: " + getLastName() + "\n";
        toReturn += "Email: " + getEmail() + "\n";
        toReturn += "Password: " + getPassword();
//        toReturn += "Their reports: "+Arrays.toString(_listOfTheirReports.toArray())
//                +"\n";
//        toReturn += "Their plan: "+_theirPlan;
        
        return toReturn;       
    }
    
}
