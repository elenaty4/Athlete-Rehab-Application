/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.util.ArrayList;

/**
 * @author Tim Yarosh
 * @version 1.0
 * @date 11/26/16
 * @section CS275.A
 */

//This interface lays out how the information obtained via the UI will be stored.
//Can be used to hold more functionalities as the program continues to develop. 
public interface Persistence {
    
    public void register(User user);
    
    public User findUser(String identifier);
    public ArrayList<User> getAllUsers();
    
    public void createInjuryReport(InjuryReportData data);
    public ArrayList<InjuryReport> findInjuryReports(String identifier);
    public ArrayList<InjuryReport> getAllInjuryReports();
    
    public void createPlan(PlanData data);
    public ArrayList<Plan> findPlans(String identifier);
    public ArrayList<Plan> getAllPlans();
    
}
