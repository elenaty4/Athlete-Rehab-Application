/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
 */
package athleterehabapplication;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * @author Elena Ngo
 * @author Tim Yarosh
 * @author Carmen Fortino
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A
 */
public class AppFrame extends JFrame {

    //These ints hold the default size of the frame
    final private int FRAME_WIDTH = 850;
    final private int FRAME_HEIGHT = 850;

    //the panel holds all of the components of the frame
    private JPanel _panel;

    /**
     * Various Buttons that have to be member data so that the ClickListener
     * class can use them.
     */
    private JButton _loginButton;

    private JButton _registerButton;

    private JButton _submitRegisterButton;

    private JButton _goBackButtonInRegisterScreen;

    private JButton _submitReportButton;

    private JButton _goBackButtonInCreateInjuryReportScreen;

    private JButton _createInjuryReportButton;

    private JButton _continuePlanButton;

    private JButton _createPlanButton;

    private JButton _findReportButton;

    private JButton _getAllInjuryReportsButton;

    private JButton _getAllPlansButton;

    private JButton _goBackButtonInFindPlanScreen;

    private JButton _goBackButtonInFindReportScreen;

    private JButton _findPlanButtonInFindPlanScreen;

    private JButton _findReportButtonInFindScreen;

    private JButton _goBackButtonInCreatePlanScreen;

    private JButton _logoutButton;

    /**
     * User will type in their email and password in these fields. The words
     * that they type in will be read once they click on the login button. Note
     * that JPasswordField is ALSO a textField but when the user types something
     * in there the words are replaced by dots for security
     */
    private JTextField _emailField;
    private JTextField _firstNameField;
    private JTextField _lastNameField;
    private JTextField _injuryDurationField;
    private JTextField _identifierField;
    private JTextField _injuryReportFirstNameField;
    private JTextField _injuryReportLastNameField;
    private JTextField _injuryReportInjuryOccuranceField;
    private JTextField _findPlanField;
    private JPasswordField _passField;
    private JTextField _injuryDescriptionField;
    private JTextField _nameField;

    private JLabel _label;

    //drop down box of Athlete and Trainer
    private JComboBox<String> _selectUserType;

    private Insets _insets;

    //holds the list of users who are registered.
    private RegisteredUsers _registeredUsers = RegisteredUsers.getInstance();

    private ActionListener _listener;
    private JComboBox<String> _intensityBox;

    private final int _fieldSize = 20;

    private InMemoryStorage _storage = new InMemoryStorage();
    private JTextField _instructionsField;
    private JTextField _durationField;
    private JButton _submitPlanButton;

    /**
     * THE METHODS BELOW CONSIST OF ADDING COMPONENTS TO THE FRAME. THEY ARE
     * SEPARATED INTO DIFFERENT PARTS: loginComponents(): adds the GUI
     * components for the Login screen. formComponents(): adds the Register
     * Screen components, Injury Report Form components, and the create Plan
     * form components. The ClickListener class in this AppFrame class is only
     * there to scan what the mouse clicked on and change the screen from it
     */
    public AppFrame() {
        getContentPane().setBackground(Color.RED);
        loginComponents();
        setSize(FRAME_WIDTH, FRAME_HEIGHT);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setResizable(true);
    }

    /**
     * Handles creating and displaying the necessary components of the login
     * screen.
     */
    private void loginComponents() {
        _listener = new ClickListener();
        _panel = new JPanel();

        createLoginPage();

        createTitleLabel();

        createInstructionLabel();

        createEmailLabel();

        createPasswordLabel();

        createEmailTextField();

        createPasswordField();

        createLoginButton();

        createRegisterButton();

        _panel.setBackground(Color.RED.darker());

        add(_panel);
    }

    private void createLoginPage() {
        _panel.setLayout(null);
        _insets = _panel.getInsets();
    }

    private void createTitleLabel() {
        Dimension size;

        _label = new JLabel("Welcome to the Athlete Rehab Application");
        _label.setFont(new Font("Arial", Font.BOLD, 20));
        _label.setForeground(Color.WHITE);
        _panel.add(_label);

        size = _label.getPreferredSize();
        _label.setBounds(10 + _insets.right, 5 + _insets.top, size.width,
                size.height);
    }

    private void createInstructionLabel() {
        Dimension size;
        _label = new JLabel("Please enter your email and password below. "
                + "And then click Login. "
                + "If you haven't signed up yet, click on Register");
        _label.setFont(new Font("Arial", Font.PLAIN, 14));
        _label.setForeground(Color.WHITE);
        _panel.add(_label);

        size = _label.getPreferredSize();
        _label.setBounds(10 + _insets.right, 40 + _insets.top, size.width,
                size.height);
    }

    private void createEmailLabel() {
        Dimension size;

        _label = new JLabel("Email: ");
        _label.setFont(new Font("Arial", Font.BOLD, 16));
        _label.setForeground(Color.WHITE);
        _panel.add(_label);

        size = _label.getPreferredSize();
        _label.setBounds(200 + _insets.left, 150 + _insets.top, size.width,
                size.height);
    }

    private void createPasswordLabel() {
        Dimension size;

        _label = new JLabel("Password: ");
        _label.setFont(new Font("Arial", Font.BOLD, 16));
        _label.setForeground(Color.WHITE);
        _panel.add(_label);

        size = _label.getPreferredSize();
        _label.setBounds(200 + _insets.left, 220 + _insets.top, size.width,
                size.height);
    }

    private void createEmailTextField() {
        Dimension size;

        _emailField = new JTextField(_fieldSize);
        _emailField.addActionListener(_listener);
        _panel.add(_emailField);

        size = _emailField.getPreferredSize();
        _emailField.setBounds(300 + _insets.left, 145 + _insets.top, size.width,
                25);
    }

    private void createPasswordField() {
        Dimension size;

        _passField = new JPasswordField(_fieldSize);
        _passField.addActionListener(_listener);
        _panel.add(_passField);

        size = _passField.getPreferredSize();
        _passField.setBounds(300 + _insets.left, 215 + _insets.top, size.width,
                25);
    }

    private void createLoginButton() {
        Dimension size;

        _loginButton = new JButton("Login");
        _panel.add(_loginButton);
        _loginButton.addActionListener(_listener);

        size = _loginButton.getPreferredSize();
        _loginButton.setBounds(360 + _insets.left, 300 + _insets.top,
                size.width, size.height);
    }

    private void createRegisterButton() {
        Dimension size;

        _registerButton = new JButton("Register");
        _registerButton.addActionListener(_listener);
        _panel.add(_registerButton);

        size = _registerButton.getPreferredSize();
        _registerButton.setBounds(352 + _insets.left, 350 + _insets.top,
                size.width, size.height);
    }

    /**
     * Uses the RegisteredUsers class and iterates through registeredAthletes
     * and registeredTrainers.
     *
     * @param email the user's inputted email
     * @param password the user's inputted password
     * @return True if the user is found in the list of registered Users. False
     * otherwise.
     */
    private boolean userExists(String email, String password) {

        boolean toReturn = false;

        ArrayList<Athlete> regAthletes;
        regAthletes = _registeredUsers.getRegisteredAthletes();

        ArrayList<Trainer> regTrainers;
        regTrainers = _registeredUsers.getRegisteredTrainers();

        String athletesEmail;
        String athletesPass;
        String trainersEmail;
        String trainersPass;

        //iterate through athletes first to check if email and password exists
        //in the system
        for (int i = 0; i < regAthletes.size(); i++) {

            athletesEmail = regAthletes.get(i).getEmail();

            athletesPass = regAthletes.get(i).getPassword();

            final boolean emailsEqual = email.equals(athletesEmail);
            final boolean passwordsEqual = password.equals(athletesPass);

            if (emailsEqual && passwordsEqual) {
                toReturn = true;
            }
        }

        if (!toReturn) //if toReturn is still false
        {
            //now iterate through the trainer's array
            for (int j = 0; j < regTrainers.size(); j++) {

                trainersEmail = regTrainers.get(j).getEmail();

                trainersPass = regTrainers.get(j).getPassword();

                final boolean trainersEmailEqual;
                trainersEmailEqual = email.equals(trainersEmail);

                final boolean trainersPasswordsEqual;
                trainersPasswordsEqual = password.equals(trainersPass);

                if (trainersEmailEqual && trainersPasswordsEqual) {
                    toReturn = true;
                }
            }
        }
        return toReturn;
    }

    /**
     * Puts in the components. When registering, once the user clicks on the
     * submit button, the information will be put in the RegisteredUsers class.
     *
     * @param formType
     */
    private void formComponents(FormType formType) {

        switch (formType) {
            case REGISTER:
                createRegisterFormComponent();
                return;

            case INJURY_REPORT:
                createInjuryReportFormComponent();
                return;

            case CREATE_PLAN:
                createPlanFormComponent();
                return;
        }
    }

    private void createRegisterFormComponent() {
        RegisterForm registerForm = new RegisterForm();

        createRegistrationLabel();

        createRegistrationInstructionsLabel();

        createRegisterFormQuestionOneLabel(registerForm);

        createRegisterFormQuestionTwoLabel(registerForm);

        createRegisterFormQuestionThreeLabel(registerForm);

        createRegisterFormQuestionFourLabel(registerForm);

        createRegisterFormQuestionFiveLabel(registerForm);

        createRegisterFormCheckBoxQuestion();

        createRegisterFormFirstNameField();

        createRegisterFormLastNameField();

        createRegisterFormEmailField();

        createRegisterFormPasswordField();

        createRegisterFormSubmitButton();

        createRegisterFormGoBackButton();
    }

    private void createRegistrationLabel() {
        Dimension size;

        _label = new JLabel("Registration");
        _label.setFont(new Font("Arial", Font.BOLD, 20));
        _label.setForeground(Color.WHITE);

        _panel.add(_label);

        size = _label.getPreferredSize();
        _label.setBounds(10 + _insets.right, 5 + _insets.top,
                size.width, size.height);
    }

    private void createRegistrationInstructionsLabel() {
        Dimension size;

        _label = new JLabel("Please fill in all of the fields and "
                + "click Submit when you're done.");
        _label.setFont(new Font("Arial", Font.BOLD, 14));
        _label.setForeground(Color.WHITE);

        _panel.add(_label);

        size = _label.getPreferredSize();
        _label.setBounds(10 + _insets.right, 30 + _insets.top, size.width,
                size.height);
    }

    private void createRegisterFormQuestionOneLabel(RegisterForm registerForm) {
        Dimension size;

        JLabel registerFormQuestionOne = new JLabel("Are you an Athlete or "
                + "a Trainer? ");
        registerFormQuestionOne.setFont(new Font("Arial", Font.BOLD, 14));
        registerFormQuestionOne.setForeground(Color.WHITE);

        _panel.add(registerFormQuestionOne);

        size = registerFormQuestionOne.getPreferredSize();
        registerFormQuestionOne.setBounds(140 + _insets.left, 100
                + _insets.top, size.width, size.height);

        registerForm.addQuestion(registerFormQuestionOne.getText());
    }

    private void createRegisterFormQuestionTwoLabel(RegisterForm registerForm) {
        Dimension size;

        JLabel registerFormQuestionTwo = new JLabel("Enter your first name: ");
        registerFormQuestionTwo.setFont(new Font("Arial", Font.BOLD, 14));
        registerFormQuestionTwo.setForeground(Color.WHITE);

        _panel.add(registerFormQuestionTwo);

        size = registerFormQuestionTwo.getPreferredSize();
        registerFormQuestionTwo.setBounds(140 + _insets.left, 150
                + _insets.top, size.width, size.height);

        registerForm.addQuestion(registerFormQuestionTwo.getText());
    }

    private void createRegisterFormQuestionThreeLabel(RegisterForm registerForm) {
        Dimension size;

        JLabel registerFormQuestionThree = new JLabel("Enter your last name: ");
        registerFormQuestionThree.setFont(new Font("Arial", Font.BOLD, 14));
        registerFormQuestionThree.setForeground(Color.WHITE);

        _panel.add(registerFormQuestionThree);

        size = registerFormQuestionThree.getPreferredSize();
        registerFormQuestionThree.setBounds(140 + _insets.left, 220
                + _insets.top, size.width, size.height);

        registerForm.addQuestion(registerFormQuestionThree.getText());
    }

    private void createRegisterFormQuestionFourLabel(RegisterForm registerForm) {
        Dimension size;

        JLabel registerFormQuestionFour = new JLabel("Enter Email: ");
        registerFormQuestionFour.setFont(new Font("Arial", Font.BOLD, 14));
        registerFormQuestionFour.setForeground(Color.WHITE);

        _panel.add(registerFormQuestionFour);

        size = registerFormQuestionFour.getPreferredSize();
        registerFormQuestionFour.setBounds(140 + _insets.left, 290
                + _insets.top, size.width, size.height);

        registerForm.addQuestion(registerFormQuestionFour.getText());
    }

    private void createRegisterFormQuestionFiveLabel(RegisterForm registerForm) {
        Dimension size;

        JLabel registerFormQuestionFive = new JLabel("Enter Password: ");
        registerFormQuestionFive.setFont(new Font("Arial", Font.BOLD, 14));
        registerFormQuestionFive.setForeground(Color.WHITE);

        _panel.add(registerFormQuestionFive);

        size = registerFormQuestionFive.getPreferredSize();
        registerFormQuestionFive.setBounds(140 + _insets.left, 360
                + _insets.top, size.width, size.height);

        registerForm.addQuestion(registerFormQuestionFive.getText());
    }

    //checkbox question. Are you Trainer or Athlete?
    private void createRegisterFormCheckBoxQuestion() {
        Dimension size;

        _selectUserType = new JComboBox<>();
        _selectUserType.addItem("Athlete");
        _selectUserType.addItem("Trainer");

        _panel.add(_selectUserType);

        size = _selectUserType.getPreferredSize();
        _selectUserType.setBounds(380 + _insets.left, 95 + _insets.top,
                size.width, size.height);
    }

    private void createRegisterFormFirstNameField() {
        Dimension size;

        _firstNameField = new JTextField(_fieldSize);

        _panel.add(_firstNameField);

        size = _firstNameField.getPreferredSize();
        _firstNameField.setBounds(300 + _insets.left, 145 + _insets.top,
                size.width, 25);
    }

    private void createRegisterFormLastNameField() {
        Dimension size;

        _lastNameField = new JTextField(_fieldSize);

        _panel.add(_lastNameField);

        size = _lastNameField.getPreferredSize();
        _lastNameField.setBounds(300 + _insets.left, 215 + _insets.top,
                size.width, 25);
    }

    private void createRegisterFormEmailField() {
        Dimension size;

        _emailField = new JTextField(_fieldSize);

        _panel.add(_emailField);

        size = _emailField.getPreferredSize();
        _emailField.setBounds(300 + _insets.left, 285 + _insets.top,
                size.width, 25);
    }

    private void createRegisterFormPasswordField() {
        Dimension size;

        _passField = new JPasswordField(_fieldSize);

        _panel.add(_passField);

        size = _passField.getPreferredSize();
        _passField.setBounds(300 + _insets.left, 355 + _insets.top,
                size.width, 25);
    }

    private void createRegisterFormSubmitButton() {
        Dimension size;

        _submitRegisterButton = new JButton("Submit");

        _submitRegisterButton.addActionListener(_listener);

        _panel.add(_submitRegisterButton);

        size = _submitRegisterButton.getPreferredSize();
        _submitRegisterButton.setBounds(300 + _insets.left,
                420 + _insets.top, size.width, size.height);
    }

    private void createRegisterFormGoBackButton() {
        Dimension size;

        _goBackButtonInRegisterScreen = new JButton("Go Back");

        _goBackButtonInRegisterScreen.addActionListener(_listener);

        _panel.add(_goBackButtonInRegisterScreen);

        size = _goBackButtonInRegisterScreen.getPreferredSize();
        _goBackButtonInRegisterScreen.setBounds(400 + _insets.left, 420
                + _insets.top, size.width, size.height);
    }

    private void createInjuryReportFormComponent() {

        InjuryReportForm injuryReportForm = new InjuryReportForm();

        createInjuryReportFormTitleLabel();

        createInjuryReportFormInstructionsLabel();

        createInjuryReportFormIdentifierLabel(injuryReportForm);

        createInjuryReportFormFirstNameLabel(injuryReportForm);

        createInjuryReportFormLastNameLabel(injuryReportForm);

        createInjuryReportFormDescriptionLabel(injuryReportForm);

        createInjuryReportFormInjuryOccurenceLabel(injuryReportForm);

        createInjuryReportFormInjuryDurationLabel(injuryReportForm);

        createInjuryReportFormIntensityLabel(injuryReportForm);

        createInjuryReportFormIdentifierField();

        createInjuryReportFormFirstNameField();

        createInjuryReportFormLastNameField();

        createInjuryReportFormDescriptionField();

        createInjuryReportFormOccurenceField();

        createInjuryReportFormDurationField();

        createInjuryReportFormIntensityField();

        createInjuryReportFormSubmitButton();

        createInjuryReportFormGoBackButton();
    }

    private void createInjuryReportFormTitleLabel() {
        Dimension size;

        JLabel injuryReportTitle = new JLabel("Report an Injury");
        injuryReportTitle.setFont(new Font("Arial", Font.BOLD, 20));

        _panel.add(injuryReportTitle);
        _insets = _panel.getInsets();

        size = injuryReportTitle.getPreferredSize();
        injuryReportTitle.setBounds(10 + _insets.right, 5 + _insets.top,
                size.width, size.height);
    }

    private void createInjuryReportFormInstructionsLabel() {
        Dimension size;

        _label = new JLabel("Please fill in all of the fields and "
                + "click Submit when you're done.");
        _label.setFont(new Font("Arial", Font.BOLD, 14));
        _label.setForeground(Color.WHITE);

        _panel.add(_label);

        size = _label.getPreferredSize();
        _label.setBounds(10 + _insets.right, 30 + _insets.top, size.width,
                size.height);
    }

    private void createInjuryReportFormIdentifierLabel(InjuryReportForm injuryReportForm) {
        Dimension size;

        JLabel identifierLabel = new JLabel("Please enter your student emali: ");
        identifierLabel.setFont(new Font("Arial", Font.BOLD, 14));

        _panel.add(identifierLabel);
        identifierLabel.setForeground(Color.WHITE);

        size = identifierLabel.getPreferredSize();
        identifierLabel.setBounds(10 + _insets.right, 145 + _insets.top,
                size.width, size.height);

        injuryReportForm.addQuestion(identifierLabel.getText());
    }

    private void createInjuryReportFormFirstNameLabel(InjuryReportForm injuryReportForm) {
        Dimension size;

        JLabel firstNameLabel = new JLabel("Please enter your first name: ");
        firstNameLabel.setFont(new Font("Arial", Font.BOLD, 14));

        _panel.add(firstNameLabel);
        firstNameLabel.setForeground(Color.WHITE);

        size = firstNameLabel.getPreferredSize();
        firstNameLabel.setBounds(10 + _insets.right, 215 + _insets.top,
                size.width, size.height);

        injuryReportForm.addQuestion(firstNameLabel.getText());
    }

    private void createInjuryReportFormLastNameLabel(InjuryReportForm injuryReportForm) {
        Dimension size;

        JLabel lastNameLabel = new JLabel("Please enter your last name: ");
        lastNameLabel.setFont(new Font("Arial", Font.BOLD, 14));

        _panel.add(lastNameLabel);
        lastNameLabel.setForeground(Color.WHITE);

        size = lastNameLabel.getPreferredSize();
        lastNameLabel.setBounds(10 + _insets.right, 285 + _insets.top, size.width,
                size.height);

        injuryReportForm.addQuestion(lastNameLabel.getText());
    }

    private void createInjuryReportFormDescriptionLabel(InjuryReportForm injuryReportForm) {
        Dimension size;

        JLabel descriptionLabel = new JLabel("Please provide a brief "
                + "description of the injury: ");
        descriptionLabel.setFont(new Font("Arial", Font.BOLD, 14));

        _panel.add(descriptionLabel);
        descriptionLabel.setForeground(Color.WHITE);

        size = descriptionLabel.getPreferredSize();
        descriptionLabel.setBounds(10 + _insets.right, 355 + _insets.top,
                size.width, size.height);

        injuryReportForm.addQuestion(descriptionLabel.getText());
    }

    private void createInjuryReportFormInjuryOccurenceLabel(InjuryReportForm injuryReportForm) {
        Dimension size;

        JLabel injuryOccuredLabel = new JLabel("When did this injury occur: ");
        injuryOccuredLabel.setFont(new Font("Arial", Font.BOLD, 14));

        _panel.add(injuryOccuredLabel);
        injuryOccuredLabel.setForeground(Color.WHITE);

        size = injuryOccuredLabel.getPreferredSize();
        injuryOccuredLabel.setBounds(10 + _insets.right, 425 + _insets.top,
                size.width, size.height);

        injuryReportForm.addQuestion(injuryOccuredLabel.getText());
    }

    private void createInjuryReportFormInjuryDurationLabel(InjuryReportForm injuryReportForm) {
        Dimension size;

        JLabel injuryDurationLabel = new JLabel("How long have you had "
                + "this injury?: ");
        injuryDurationLabel.setFont(new Font("Arial", Font.BOLD, 14));

        _panel.add(injuryDurationLabel);
        injuryDurationLabel.setForeground(Color.WHITE);

        size = injuryDurationLabel.getPreferredSize();
        injuryDurationLabel.setBounds(10 + _insets.right, 495 + _insets.top, size.width,
                size.height);

        injuryReportForm.addQuestion(injuryDurationLabel.getText());
    }

    private void createInjuryReportFormIntensityLabel(InjuryReportForm injuryReportForm) {
        Dimension size;

        JLabel intensityLabel = new JLabel("On a scale of 0 to 10 how would "
                + "you rate this injury(0 being the lowest intesity,"
                + " 10 being the highest): ");
        intensityLabel.setFont(new Font("Arial", Font.BOLD, 14));

        _panel.add(intensityLabel);
        intensityLabel.setForeground(Color.WHITE);

        size = intensityLabel.getPreferredSize();
        intensityLabel.setBounds(10 + _insets.right, 570 + _insets.top,
                size.width, size.height);

        injuryReportForm.addQuestion(intensityLabel.getText());
    }

    private void createInjuryReportFormIdentifierField() {
        Dimension size;

        _identifierField = new JTextField(_fieldSize);

        _panel.add(_identifierField);

        size = _identifierField.getPreferredSize();
        _identifierField.setBounds(350 + _insets.left, 145 + _insets.top,
                size.width, 25);
    }

    private void createInjuryReportFormFirstNameField() {
        Dimension size;

        _injuryReportFirstNameField = new JTextField(_fieldSize);
        _panel.add(_injuryReportFirstNameField);

        size = _injuryReportFirstNameField.getPreferredSize();
        _injuryReportFirstNameField.setBounds(350 + _insets.left, 215
                + _insets.top, size.width, 25);
    }

    private void createInjuryReportFormLastNameField() {
        Dimension size;

        _injuryReportLastNameField = new JTextField(_fieldSize);
        _panel.add(_injuryReportLastNameField);

        size = _injuryReportLastNameField.getPreferredSize();
        _injuryReportLastNameField.setBounds(350 + _insets.left, 285
                + _insets.top, size.width, 25);
    }

    private void createInjuryReportFormDescriptionField() {
        Dimension size;

        _injuryDescriptionField = new JTextField(_fieldSize);
        _panel.add(_injuryDescriptionField);

        size = _injuryDescriptionField.getPreferredSize();
        _injuryDescriptionField.setBounds(350 + _insets.left, 355
                + _insets.top, size.width, 25);
    }

    private void createInjuryReportFormOccurenceField() {
        Dimension size;

        _injuryReportInjuryOccuranceField = new JTextField(_fieldSize);
        _panel.add(_injuryReportInjuryOccuranceField);

        size = _injuryReportInjuryOccuranceField.getPreferredSize();
        _injuryReportInjuryOccuranceField.setBounds(350 + _insets.left, 425
                + _insets.top, size.width, 25);
    }

    private void createInjuryReportFormDurationField() {
        Dimension size;

        _injuryDurationField = new JTextField(_fieldSize);
        _panel.add(_injuryDurationField);

        size = _injuryDurationField.getPreferredSize();
        _injuryDurationField.setBounds(350 + _insets.left, 495
                + _insets.top, size.width, 25);
    }

    private void createInjuryReportFormIntensityField() {
        Dimension size;

        _intensityBox = new JComboBox<>();
        _intensityBox.addItem("0");
        _intensityBox.addItem("1");
        _intensityBox.addItem("2");
        _intensityBox.addItem("3");
        _intensityBox.addItem("4");
        _intensityBox.addItem("5");
        _intensityBox.addItem("6");
        _intensityBox.addItem("7");
        _intensityBox.addItem("8");
        _intensityBox.addItem("9");
        _intensityBox.addItem("10");
        _panel.add(_intensityBox);

        size = _intensityBox.getPreferredSize();
        _intensityBox.setBounds(775 + _insets.left, 570 + _insets.top,
                size.width, size.height);
    }

    private void createInjuryReportFormSubmitButton() {
        Dimension size;

        _submitReportButton = new JButton("Submit");
        _submitReportButton.addActionListener(_listener);
        _panel.add(_submitReportButton);

        size = _submitReportButton.getPreferredSize();
        _submitReportButton.setBounds(300 + _insets.left, 640
                + _insets.top, size.width, size.height);
    }

    private void createInjuryReportFormGoBackButton() {
        Dimension size;

        _goBackButtonInCreateInjuryReportScreen = new JButton("Go Back");
        _goBackButtonInCreateInjuryReportScreen.addActionListener(_listener);
        _panel.add(_goBackButtonInCreateInjuryReportScreen);

        size = _goBackButtonInCreateInjuryReportScreen.getPreferredSize();
        _goBackButtonInCreateInjuryReportScreen.setBounds(400 + _insets.left,
                640 + _insets.top, size.width, size.height);
    }

    private void createPlanFormComponent() {
        Dimension size;

        PlanForm planForm = new PlanForm();

        JLabel createPlanTitle = new JLabel("Create a Plan");
        createPlanTitle.setFont(new Font("Arial", Font.BOLD, 20));
        _panel.add(createPlanTitle);

        size = createPlanTitle.getPreferredSize();
        createPlanTitle.setBounds(10 + _insets.right, 5 + _insets.top,
                size.width, size.height);

        JLabel planInstructionsLabel = new JLabel("Please fill out all of "
                + "the fields. Once you are finished, hit submit.");
        planInstructionsLabel.setFont(new Font("Arial", Font.BOLD, 20));
        _panel.add(planInstructionsLabel);

        size = planInstructionsLabel.getPreferredSize();
        planInstructionsLabel.setBounds(10 + _insets.right, 25
                + _insets.top, size.width, size.height);

        //JLabels
        JLabel planFormQuestionOne = new JLabel("Please enter your first and "
                + "last name: ");
        planFormQuestionOne.setFont(new Font("Arial", Font.BOLD, 20));
        _panel.add(planFormQuestionOne);

        size = planFormQuestionOne.getPreferredSize();
        planFormQuestionOne.setBounds(10 + _insets.right, 140 + _insets.top,
                size.width, size.height);

        planForm.addQuestion(planFormQuestionOne.getText());

        JLabel planFormQuestionTwo = new JLabel("Please enter any instructions "
                + "an athlete should take for their injury: ");
        planFormQuestionTwo.setFont(new Font("Arial", Font.BOLD, 20));
        _panel.add(planFormQuestionTwo);

        size = planFormQuestionTwo.getPreferredSize();
        planFormQuestionTwo.setBounds(10 + _insets.right, 190 + _insets.top,
                size.width, size.height);

        planForm.addQuestion(planFormQuestionTwo.getText());

        JLabel planFormQuestionThree = new JLabel("Please enter how long you "
                + "estimate the athlete will be out injured: ");
        planFormQuestionThree.setFont(new Font("Arial", Font.BOLD, 20));
        _panel.add(planFormQuestionThree);

        size = planFormQuestionThree.getPreferredSize();
        planFormQuestionThree.setBounds(10 + _insets.right, 240 + _insets.top,
                size.width, size.height);

        planForm.addQuestion(planFormQuestionThree.getText());

        //JTextFields
        _nameField = new JTextField(_fieldSize);
        _panel.add(_nameField);

        size = _nameField.getPreferredSize();
        _nameField.setBounds(675 + _insets.left, 140 + _insets.top,
                size.width, 25);

        _instructionsField = new JTextField(_fieldSize);
        _panel.add(_instructionsField);

        size = _instructionsField.getPreferredSize();
        _instructionsField.setBounds(675 + _insets.left, 190 + _insets.top,
                size.width, 25);

        _durationField = new JTextField(_fieldSize);
        _panel.add(_durationField);

        size = _durationField.getPreferredSize();
        _durationField.setBounds(675 + _insets.left, 240 + _insets.top,
                size.width, 25);

        _submitPlanButton = new JButton("Create Plan");
        _submitPlanButton.addActionListener(_listener);
        _panel.add(_submitPlanButton);

        size = _submitPlanButton.getPreferredSize();
        _submitPlanButton.setBounds(350 + _insets.left,
                500 + _insets.top, size.width, size.height);

        _goBackButtonInCreatePlanScreen = new JButton("Go Back");
        _goBackButtonInCreatePlanScreen.addActionListener(_listener);
        _panel.add(_goBackButtonInCreatePlanScreen);

        size = _goBackButtonInCreatePlanScreen.getPreferredSize();
        _goBackButtonInCreatePlanScreen.setBounds(500 + _insets.left,
                500 + _insets.top, size.width, size.height);

    }

    private void createFindReportGoBackButton() {
        Dimension size;

        _goBackButtonInFindReportScreen = new JButton("Go Back");
        _goBackButtonInFindReportScreen.addActionListener(_listener);
        _panel.add(_goBackButtonInFindReportScreen);

        size = _goBackButtonInFindReportScreen.getPreferredSize();
        _goBackButtonInFindReportScreen.setBounds(450 + _insets.left,
                500 + _insets.top, size.width, size.height);
    }

    private void createFindReportButtonInFind() {
        Dimension size;

        _findReportButtonInFindScreen = new JButton("Find");
        _findReportButtonInFindScreen.addActionListener(_listener);
        _panel.add(_findReportButtonInFindScreen);

        size = _findReportButtonInFindScreen.getPreferredSize();
        _findReportButtonInFindScreen.setBounds(350 + _insets.left,
                500 + _insets.top, size.width, size.height);
    }

    /**
     * This class listens to the user's clicks in the application
     */
    public class ClickListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            final boolean theActionPerformedWasLogin;
            theActionPerformedWasLogin = event.getSource() == _loginButton;

            final boolean theActionPerformedWasRegister;
            theActionPerformedWasRegister = event.getSource() == _registerButton;

            final boolean theActionPerformedWasSubmitRegister;
            theActionPerformedWasSubmitRegister
                    = event.getSource() == _submitRegisterButton;

            final boolean theActionPerformedWasGoBackToRegister;
            theActionPerformedWasGoBackToRegister
                    = event.getSource() == _goBackButtonInRegisterScreen;

            final boolean theActionPerformedWasCreateInjuryReport;
            theActionPerformedWasCreateInjuryReport
                    = event.getSource() == _createInjuryReportButton;

            final boolean theActionPerformedWasSubmitInjuryReport;
            theActionPerformedWasSubmitInjuryReport
                    = event.getSource() == _submitReportButton;

            final boolean theActionPerformedWasFindYourPlan;
            theActionPerformedWasFindYourPlan = event.getSource()
                    == _continuePlanButton;

            final boolean theActionPerformedWasGoBackToAthleteMenu;
            theActionPerformedWasGoBackToAthleteMenu
                    = event.getSource()
                    == _goBackButtonInCreateInjuryReportScreen
                    || event.getSource() == _goBackButtonInFindPlanScreen;

            final boolean theActionPerformedWasGoBackToTrainerMenu;
            theActionPerformedWasGoBackToTrainerMenu = event.getSource()
                    == _goBackButtonInFindPlanScreen
                    || event.getSource() == _goBackButtonInFindReportScreen
                    || event.getSource() == _goBackButtonInCreatePlanScreen;

            final boolean theActionPerformedWasLogout;
            theActionPerformedWasLogout = event.getSource() == _logoutButton;

            final boolean theActionPerformedWasCreateAPlan;
            theActionPerformedWasCreateAPlan = event.getSource()
                    == _createPlanButton;

            final boolean actionPerformedGetAllAvailablePlans;
            actionPerformedGetAllAvailablePlans = event.getSource()
                    == _getAllPlansButton;

            final boolean theActionPerformedWasFindInjuryReport;
            theActionPerformedWasFindInjuryReport = event.getSource()
                    == _findReportButton;

            final boolean theActionPerformedWasFindInFindScreen;
            theActionPerformedWasFindInFindScreen = event.getSource()
                    == _findReportButtonInFindScreen;

            final boolean theActionPerformedIsGetAllReports;
            theActionPerformedIsGetAllReports = event.getSource()
                    == _getAllInjuryReportsButton;

            final boolean theActionPerformedIsFindPlan;
            theActionPerformedIsFindPlan = event.getSource()
                    == _findPlanButtonInFindPlanScreen;

            final boolean theActionPerformedWasSubmitPlan;
            theActionPerformedWasSubmitPlan = event.getSource()
                    == _submitPlanButton;

            if (theActionPerformedWasLogin) {
                //get input from user
                String emailInput = _emailField.getText();
                String passwordInput = Arrays.toString(_passField.getPassword());

                boolean userExists = userExists(emailInput, passwordInput);

                /**
                 * If user is in the system, check their user type. Screen will
                 * then change according to the userType. Components are also
                 * added to the screen based on the user type.
                 */
                if (userExists) {
                    System.out.println("User exists!");

                    _panel.removeAll();

                    String userType = (String) _selectUserType.getSelectedItem();
                    final boolean userIsAnAthlete = userType.equals("Athlete");
                    final boolean userIsATrainer = userType.equals("Trainer");

                    if (userIsAnAthlete) {
                        createAndDisplayAthleteMenu();

                    } else if (userIsATrainer) {
                        createAndDisplayTrainerMenu();
                    }

                    _panel.revalidate();
                    _panel.repaint();

                } else {
                    createAndDisplayUserDoesNotExistLabel();
                }
            } else if (theActionPerformedWasRegister) {

                moveToRegisterScreen();

            } else if (theActionPerformedWasSubmitRegister) {

                registerTheUserAndReturnToLoginScreen();

            } else if (theActionPerformedWasGoBackToRegister) {

                _panel.removeAll();
                loginComponents();
                _panel.revalidate();
                _panel.repaint();

            } else if (theActionPerformedWasCreateInjuryReport) {

                moveToCreateInjuryReportScreen();

            } else if (theActionPerformedWasSubmitInjuryReport) {

                //Check if user filled in all of the parts
                String firstNameInput = _injuryReportFirstNameField.getText();
                String lastNameInput = _injuryReportLastNameField.getText();
                String identifierInput = _identifierField.getText();
                String injuryOccurrenceInput = _injuryReportInjuryOccuranceField
                        .getText();
                String injuryDurationInput = _injuryDurationField.getText();
                String injuryIntensityInput = (String) _intensityBox.
                        getSelectedItem();
                String descriptionInput = _injuryDescriptionField.getText();

                boolean aTextFieldIsEmpty = firstNameInput.isEmpty()
                        || lastNameInput.isEmpty()
                        || descriptionInput.isEmpty()
                        || identifierInput.isEmpty()
                        || injuryOccurrenceInput.isEmpty()
                        || injuryDurationInput.isEmpty()
                        || injuryIntensityInput.isEmpty();

                if (aTextFieldIsEmpty) {
                    JLabel inputNotValid = new JLabel("One or more fields are "
                            + "empty." + " Please fill them in.");
                    inputNotValid.setForeground(Color.YELLOW);
                    _panel.add(inputNotValid);

                    Dimension size = inputNotValid.getPreferredSize();

                    inputNotValid.setBounds(10 + _insets.right, 50 + _insets.top,
                            size.width, size.height);

                } else {

                    InjuryReportData data = new InjuryReportData();

                    data._firstName = firstNameInput;
                    data._lastName = lastNameInput;
                    data._identifier = identifierInput;
                    data._description = descriptionInput;
                    data._dayInjuryOccured = injuryOccurrenceInput;
                    data._injuryDuration = injuryDurationInput;
                    data._intensity = injuryIntensityInput;

                    _storage.createInjuryReport(data);

                    JLabel injuryReportCreatedSuccessfullyLabel = new JLabel(""
                            + "Injury report created successfully.");
                    injuryReportCreatedSuccessfullyLabel.setForeground(
                            Color.YELLOW);
                    _panel.add(injuryReportCreatedSuccessfullyLabel);

                    Dimension size = injuryReportCreatedSuccessfullyLabel.
                            getPreferredSize();

                    injuryReportCreatedSuccessfullyLabel.setBounds(10
                            + _insets.right, 60 + _insets.top,
                            size.width, size.height);
                }
            } else if (theActionPerformedWasCreateAPlan) {
                _panel.removeAll();
                formComponents(FormType.CREATE_PLAN);
                _panel.revalidate();
                _panel.repaint();

            } else if (theActionPerformedWasFindYourPlan) {
                moveToFindAPlanScreen();

            } else if (theActionPerformedWasGoBackToAthleteMenu) {

                _panel.removeAll();
                createAndDisplayAthleteMenu();
                _panel.revalidate();
                _panel.repaint();

            } else if (theActionPerformedWasFindInjuryReport) {

                _panel.removeAll();
                Dimension size;

                JLabel findReportLabel = new JLabel("Enter the email used to create "
                        + "report: ");
                findReportLabel.setFont(new Font("Arial", Font.BOLD, 20));

                _panel.add(findReportLabel);
                _insets = _panel.getInsets();

                size = findReportLabel.getPreferredSize();
                findReportLabel.setBounds(10 + _insets.right, 145 + _insets.top,
                        size.width, size.height);

                _panel.revalidate();
                _panel.repaint();

                _emailField = new JTextField(_fieldSize);

                _panel.add(_emailField);

                size = _emailField.getPreferredSize();
                _emailField.setBounds(380 + _insets.left, 145 + _insets.top,
                        size.width, 25);

                createFindReportGoBackButton();
                createFindReportButtonInFind();

            } else if (theActionPerformedWasFindInFindScreen) {

                InjuryReportData data = new InjuryReportData();
                data._identifier = _emailField.getText();
                System.out.println("The Identifier chosen is: " + data._identifier);

                System.out.println("REPORT: ");
                System.out.println(_storage.findInjuryReports(data._identifier));

            } else if (theActionPerformedWasGoBackToAthleteMenu) {

                _panel.removeAll();
                createAndDisplayAthleteMenu();
                _panel.revalidate();
                _panel.repaint();

            } else if (theActionPerformedWasGoBackToTrainerMenu) {

                _panel.removeAll();
                createAndDisplayTrainerMenu();
                _panel.revalidate();
                _panel.repaint();

            } else if (theActionPerformedWasLogout) {

                _panel.removeAll();
                loginComponents();
                _panel.revalidate();
                _panel.repaint();
            } else if (actionPerformedGetAllAvailablePlans) {

                System.out.println("All available plans: "
                        + _storage.getAllPlans());
            } else if (theActionPerformedIsGetAllReports) {

                System.out.println("All available reports: ");
                System.out.println(_storage.getAllInjuryReports());

            } else if (theActionPerformedIsFindPlan) {

                PlanData data = new PlanData();
                data._identifier = _findPlanField.getText();

                System.out.println(_storage.findPlans(data._identifier));

            } else if (theActionPerformedWasSubmitPlan) {

                String identifierInput = _nameField.getText();
                String instructionsInput = _instructionsField.getText();
                String durationInput = _durationField.getText();

                PlanData data = new PlanData();
                data._identifier = identifierInput;
                data._instructions = instructionsInput;
                data._estimatedDuration = durationInput;

                _storage.createPlan(data);

                JLabel planCreatedSuccessfullyLabel = new JLabel(""
                        + "plan created successfully.");
                planCreatedSuccessfullyLabel.setForeground(
                        Color.YELLOW);
                _panel.add(planCreatedSuccessfullyLabel);

                Dimension size = planCreatedSuccessfullyLabel.
                        getPreferredSize();

                planCreatedSuccessfullyLabel.setBounds(10
                        + _insets.right, 60 + _insets.top,
                        size.width, size.height);

            }
        }

        private void moveToFindAPlanScreen() {
            _panel.removeAll();

            createFindAPlanLabel();

            createFindAPlanInstructionsLabel();

            createFindAPlanField();

            createFindAPlanButton();

            createGoBackButtonInFindAPlan();

            _panel.revalidate();
            _panel.repaint();
        }

        private void createGoBackButtonInFindAPlan() {
            Dimension size;

            _goBackButtonInFindPlanScreen = new JButton("Go Back");
            _goBackButtonInFindPlanScreen.addActionListener(_listener);
            _panel.add(_goBackButtonInFindPlanScreen);

            size = _goBackButtonInFindPlanScreen.getPreferredSize();
            _goBackButtonInFindPlanScreen.setBounds(400 + _insets.left,
                    640 + _insets.top, size.width, size.height);
        }

        private void createFindAPlanButton() {
            Dimension size;

            _findPlanButtonInFindPlanScreen = new JButton("Find");
            _findPlanButtonInFindPlanScreen.addActionListener(_listener);
            _panel.add(_findPlanButtonInFindPlanScreen);

            size = _findPlanButtonInFindPlanScreen.getPreferredSize();
            _findPlanButtonInFindPlanScreen.setBounds(300 + _insets.left,
                    640 + _insets.top, size.width, size.height);
        }

        private void createFindAPlanField() {
            Dimension size;

            _findPlanField = new JTextField(_fieldSize);

            _panel.add(_findPlanField);

            size = _findPlanField.getPreferredSize();
            _findPlanField.setBounds(650 + _insets.left, 25 + _insets.top,
                    size.width, 25);
        }

        private void createFindAPlanInstructionsLabel() {
            Dimension size;

            JLabel findYourPlanInstructionsLabel = new JLabel("Please "
                    + "enter the first and last name of the plan you "
                    + "wish to find:");
            findYourPlanInstructionsLabel.setFont(
                    new Font("Arial", Font.BOLD, 20));

            _panel.add(findYourPlanInstructionsLabel);
            _insets = _panel.getInsets();

            size = findYourPlanInstructionsLabel.getPreferredSize();
            findYourPlanInstructionsLabel.setBounds(10 + _insets.right,
                    25 + _insets.top, size.width, size.height);
        }

        private void createFindAPlanLabel() {
            Dimension size;

            JLabel findYourPlanLabel = new JLabel("Find a plan");
            findYourPlanLabel.setFont(new Font("Arial", Font.BOLD, 20));

            _panel.add(findYourPlanLabel);
            _insets = _panel.getInsets();

            size = findYourPlanLabel.getPreferredSize();
            findYourPlanLabel.setBounds(10 + _insets.right, 5 + _insets.top,
                    size.width, size.height);
        }

        private void moveToCreateInjuryReportScreen() {
            _panel.removeAll();
            formComponents(FormType.INJURY_REPORT);
            _panel.revalidate();
            _panel.repaint();
        }

        private void registerTheUserAndReturnToLoginScreen() {
            //FIRST check if user filled in all of the parts
            String userType = (String) _selectUserType.getSelectedItem();
            String firstNameInput = _firstNameField.getText();
            String lastNameInput = _lastNameField.getText();
            String emailInput = _emailField.getText();
            String passInput = Arrays.toString(_passField.getPassword());

            boolean aTextFieldIsEmpty = firstNameInput.isEmpty()
                    || lastNameInput.isEmpty() || emailInput.isEmpty()
                    || passInput.length() == 2;

            if (aTextFieldIsEmpty) {
                JLabel inputNotValid = new JLabel("One or more fields are "
                        + "empty." + " Please fill them in.");
                inputNotValid.setForeground(Color.YELLOW);
                _panel.add(inputNotValid);

                Dimension size = inputNotValid.getPreferredSize();

                inputNotValid.setBounds(10 + _insets.right, 50 + _insets.top,
                        size.width, size.height);

            } else //The text fields are NOT empty
            {
                if (userType.equals("Athlete")) {

                    User user = new Athlete();

                    user.setFirstName(firstNameInput);
                    user.setLastName(lastNameInput);
                    user.setEmail(emailInput);
                    user.setPassword(passInput);

                    _storage.register(user);

                    _registeredUsers.addAthlete((Athlete) user);

                } else if (userType.equals("Trainer")) {
                    User user = new Trainer();

                    user.setFirstName(firstNameInput);
                    user.setLastName(lastNameInput);
                    user.setEmail(emailInput);
                    user.setPassword(passInput);

                    _storage.register(user);

                    _registeredUsers.addTrainer((Trainer) user);
                }

                _panel.removeAll();
                loginComponents(); //goes back to login screen

                JLabel registrationSuccessful = new JLabel("Registration "
                        + "successful!");

                registrationSuccessful.setForeground(Color.WHITE);
                _panel.add(registrationSuccessful);
                Dimension size = registrationSuccessful.
                        getPreferredSize();

                registrationSuccessful.setBounds(10 + _insets.right,
                        60 + _insets.top,
                        size.width, size.height);

                _panel.revalidate();
                _panel.repaint();
            }
        }

        private void moveToRegisterScreen() {
            _panel.removeAll();
            formComponents(FormType.REGISTER);
            _panel.revalidate();
            _panel.repaint();
        }

        private void createAndDisplayUserDoesNotExistLabel() {
            JLabel userNoExist = new JLabel("Email or Password are "
                    + "incorrect. Please try again");
            userNoExist.setForeground(Color.YELLOW);
            _panel.add(userNoExist);
            Dimension size = userNoExist.getPreferredSize();

            userNoExist.setBounds(10 + _insets.right, 100 + _insets.top,
                    size.width, size.height);
        }

        private void createAndDisplayTrainerMenu() {
            createTrainerMenuLabel();

            createTrainerMenuCreatePlanButton();

            createTrainerMenuFindInjuryReportButton();

            createTrainerMenuFindPlanButton();

            createTrainerMenuGetAllInjuryReportsButton();

            createTrainerMenuGetAllPlansButton();

            createMenuLogOutButton();
        }

        private void createTrainerMenuGetAllPlansButton() {
            Dimension size;

            _getAllPlansButton = new JButton("Get all available "
                    + "plans");
            _getAllPlansButton.addActionListener(_listener);

            _panel.add(_getAllPlansButton);

            size = _getAllPlansButton.getPreferredSize();
            _getAllPlansButton.setBounds(300
                    + _insets.left, 320 + _insets.top,
                    size.width, size.height);
        }

        private void createTrainerMenuGetAllInjuryReportsButton() {
            Dimension size;

            _getAllInjuryReportsButton = new JButton("Get all "
                    + "available injury reports");
            _getAllInjuryReportsButton.addActionListener(_listener);

            _panel.add(_getAllInjuryReportsButton);

            size = _getAllInjuryReportsButton.getPreferredSize();
            _getAllInjuryReportsButton.setBounds(300
                    + _insets.left, 280 + _insets.top,
                    size.width, size.height);
        }

        private void createTrainerMenuFindPlanButton() {
            Dimension size;

            _continuePlanButton = new JButton("Find a plan");
            _continuePlanButton.addActionListener(_listener);

            _panel.add(_continuePlanButton);

            size = _continuePlanButton.getPreferredSize();
            _continuePlanButton.setBounds(300 + _insets.left, 240
                    + _insets.top, size.width, size.height);
        }

        private void createTrainerMenuFindInjuryReportButton() {
            Dimension size;

            _findReportButton = new JButton("Find an injury report");
            _findReportButton.addActionListener(_listener);

            _panel.add(_findReportButton);

            size = _findReportButton.getPreferredSize();
            _findReportButton.setBounds(300 + _insets.left, 190
                    + _insets.top, size.width, size.height);
        }

        private void createTrainerMenuCreatePlanButton() {
            Dimension size;

            _createPlanButton = new JButton("Create a plan");
            _createPlanButton.addActionListener(_listener);

            _panel.add(_createPlanButton);

            size = _createPlanButton.getPreferredSize();
            _createPlanButton.setBounds(300 + _insets.left, 150
                    + _insets.top, size.width, size.height);
        }

        private void createTrainerMenuLabel() {

            _label = new JLabel("Hello, " + _firstNameField.getText()
                    + ", Select one of the options below");
            _label.setFont(new Font("Arial", Font.BOLD, 18));
            _label.setForeground(Color.WHITE);
            _panel.add(_label);
            Dimension size = _label.getPreferredSize();
            _label.setBounds(10 + _insets.right, 5 + _insets.top,
                    size.width, size.height);
        }

        private void createAndDisplayAthleteMenu() {
            createAthleteMenuInstructionsLabel();

            createAthleteMenuCreateInjuryReportButton();

            createAthleteMenuContinuePlanButton();

            createMenuLogOutButton();
        }

        private void createAthleteMenuInstructionsLabel() {
            Dimension size;

            _label = new JLabel("Hello, " + _firstNameField.getText()
                    + ", Select one of the options below");
            _label.setFont(new Font("Arial", Font.BOLD, 18));
            _label.setForeground(Color.WHITE);

            _panel.add(_label);

            size = _label.getPreferredSize();
            _label.setBounds(10 + _insets.right, 5 + _insets.top,
                    size.width, size.height);
        }

        private void createAthleteMenuCreateInjuryReportButton() {
            Dimension size;

            _createInjuryReportButton
                    = new JButton("Create Injury Report");
            _createInjuryReportButton.addActionListener(_listener);

            _panel.add(_createInjuryReportButton);

            size = _createInjuryReportButton.getPreferredSize();
            _createInjuryReportButton.setBounds(300 + _insets.left,
                    150 + _insets.top, size.width, size.height);

        }

        private void createAthleteMenuContinuePlanButton() {
            Dimension size;

            _continuePlanButton = new JButton("Find your Plan");
            _continuePlanButton.addActionListener(_listener);

            _panel.add(_continuePlanButton);

            size = _continuePlanButton.getPreferredSize();
            _continuePlanButton.setBounds(300 + _insets.left, 190
                    + _insets.top, size.width, size.height);

        }

        private void createMenuLogOutButton() {
            Dimension size;

            _logoutButton = new JButton("Log Out");
            _logoutButton.addActionListener(_listener);

            _panel.add(_logoutButton);

            size = _logoutButton.getPreferredSize();
            _logoutButton.setBounds(300 + _insets.left, 360 + _insets.top,
                    size.width, size.height);
        }

    }
}
