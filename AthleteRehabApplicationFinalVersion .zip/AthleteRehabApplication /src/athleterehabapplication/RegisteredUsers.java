/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.util.ArrayList;

/**
 * @author Elena Ngo
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A
 */
public class RegisteredUsers {

    private ArrayList<Athlete> _registeredAthletes;
    private ArrayList<Trainer> _registeredTrainers;
    private static RegisteredUsers _instance;

    private RegisteredUsers() {
        _registeredAthletes = new ArrayList<>();
        _registeredTrainers = new ArrayList<>();
    }

    //getters
    public static RegisteredUsers getInstance() {

        if (_instance == null) {

            _instance = new RegisteredUsers();
        }

        return _instance;
    }

    public ArrayList<Athlete> getRegisteredAthletes() {
        return _registeredAthletes;
    }

    public ArrayList<Trainer> getRegisteredTrainers() {
        return _registeredTrainers;
    }

    public void addAthlete(Athlete athlete) {
        _registeredAthletes.add(athlete);
    }

    public void addTrainer(Trainer trainer) {
        _registeredTrainers.add(trainer);
    }

    @Override
    public String toString() {
        String toReturn = "";
        for (int i = 0; i < _registeredAthletes.size(); i++) {
            toReturn = toReturn + _registeredAthletes.get(i).toString() + "\n";
        }

        for (int j = 0; j < _registeredTrainers.size(); j++) {
            toReturn = toReturn + _registeredTrainers.get(j).toString() + "\n";
        }

        return toReturn;
    }
}
