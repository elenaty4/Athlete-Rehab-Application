/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * @author Tim Yarosh
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A
 */
public class RegisterForm extends Form {

    private ArrayList<String> _questions;
    private String _email;
    private String _password;
    private String _firstName;
    private String _lastName;

    public RegisterForm() {
        _questions = getQuestions();
    }

    public void register() {
        
        User user = new User();
        
        _email = user.getEmail();
        _password = user.getPassword();
        _firstName = user.getFirstName();
        _lastName = user.getLastName();
                
        InMemoryStorage storage = new InMemoryStorage();
        storage.register(user);

    }
    
    //getter
    public static ArrayList<String> getQuestions() {
        return Form.getQuestions();
    }

    //toString
    @Override
    public String toString() {
        String toReturn = Arrays.toString(_questions.toArray());

        toReturn += "\n"+"Email: " + _email + "\n";
        toReturn += "Password: " + _password;

        return toReturn;
    }
}
