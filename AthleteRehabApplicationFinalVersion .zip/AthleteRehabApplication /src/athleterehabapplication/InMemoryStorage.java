/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.util.ArrayList;

/**
 * @author Tim Yarosh
 * @version 1.0
 * @date 11/26/16
 * @section CS275.A
 */
public class InMemoryStorage implements Persistence {
    
    private static ArrayList<InjuryReport> _injuryReports;
    private static ArrayList<User> _users;
    private static ArrayList<Plan> _plans;
    
    public InMemoryStorage() {
        _injuryReports = new ArrayList<>();
        _users = new ArrayList<>();
        _plans = new ArrayList<>();
    }
    
    //method put on register screen; method implemented 
    @Override
    public void register(User user) {
        _users.add(user);
    }
    
    //to be put on the trainer menu; not implemented yet
    @Override
    public User findUser(String identifier) {
        for (User u : _users) {
            if (u.getEmail().equals(identifier)) {
                return u;
            }
        }
        return null;
    }
    
    //method put on athlete screen; method implemented
    @Override
    public void createInjuryReport(InjuryReportData data) {
        _injuryReports.add(new InjuryReport(data));
    }
    
    //method is on trainer menu; not implemented yet
    @Override
    public ArrayList<InjuryReport> findInjuryReports(String identifier) {
        
        ArrayList<InjuryReport> report = new ArrayList<>();
        
        for (InjuryReport r : _injuryReports) {
            if (r.getIndentifier().equals(identifier)) {
                report.add(r);
            }
        }
        return report;
    }
    
    //method is on trainer menu; not implemented yet
    @Override
    public ArrayList<InjuryReport> getAllInjuryReports() {
        return _injuryReports;
    }
    
    //method is on trainer menu; not implemented yet
    @Override
    public void createPlan(PlanData data) {
        _plans.add(new Plan(data));
    }
    
    //method is both screens; not implemented yet
    @Override
    public ArrayList<Plan> findPlans(String identifier) {
        
        ArrayList<Plan> plans = new ArrayList<>();
        
        for (Plan p : _plans) {
            if (p.getIdentifier().equals(identifier)) {
                plans.add(p);
            }
        }
        return plans;
    }
    
    //method is on the trainer menu; not implemented yet
    @Override
    public ArrayList<Plan> getAllPlans() {
        return _plans;
    }
    
    @Override
    public ArrayList<User> getAllUsers() {
        return _users;
    }
    
}
