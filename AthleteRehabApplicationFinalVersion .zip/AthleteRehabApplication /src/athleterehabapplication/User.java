/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

/**
 * @author Elena Ngo
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A
 */
public class User {

    private String _firstName;
    private String _lastName;
    private String _email;
    private String _password;

    UserType _userType;

    public String getFirstName() {
        return _firstName;
    }

    public String getLastName() {
        return _lastName;
    }

    public String getPassword() {
        return _password;
    }

    public String getEmail() {
        return _email;
    }

    public void setFirstName(String newFirstName) {
        _firstName = newFirstName;
    }

    public void setLastName(String newLastName) {
        _lastName = newLastName;
    }

    public void setEmail(String newEmail) {
        _email = newEmail;
    }

    public void setPassword(String newPassword) {
        _password = newPassword;
    }

    //toString method
    //returns a string representation of the object
    @Override
    /**
     *
     */
    public String toString() {
        String toReturn = "User type: " + _userType + "\n";
        toReturn += "First name: " + _firstName + "\n";
        toReturn += "Last name: " + _lastName + "\n";
        toReturn += "Email: " + _email + "\n";
        
        return toReturn;
    }
}
