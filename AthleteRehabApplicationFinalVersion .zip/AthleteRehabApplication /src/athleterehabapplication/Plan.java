/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.time.LocalTime;

/**
 * @author Tim Yarosh
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A
 */
public class Plan {

    private LocalTime _timePlanWasCreated;
    private String _instructions;
    private String _estimatedDuration;
    private String _identifier;

    public Plan(PlanData data) {

        _timePlanWasCreated = LocalTime.now();
        _instructions = data._instructions;
        _estimatedDuration = data._estimatedDuration;
        _identifier = data._identifier;
    }

    //getters
    public LocalTime getTimeCreated() {
        return _timePlanWasCreated;
    }

    public String getInstructions() {
        return _instructions;
    }

    public String getEstimatedDuration() {
        return _estimatedDuration;
    }

    public String getIdentifier() {
        return _identifier;
    }

    @Override
    public String toString() {
        String toReturn = "Time created: " + _timePlanWasCreated.toString() + "\n";
        toReturn += "Instructions: " + _instructions + "\n";
        toReturn += "Estimated duration: " + _estimatedDuration + "\n";
        toReturn += "Specfic identifier: " + _identifier;

        return toReturn;
    }
}
