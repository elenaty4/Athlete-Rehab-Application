/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.util.ArrayList;

/**
 * @author Tim Yarosh
 * @version 1.0
 * @date 11/14/16
 * @section CS275.A
 */
public class InjuryReportForm extends Form {

    private InjuryReport _injuryReport;
    private ArrayList<String> _questions;

    public InjuryReportForm() {
        //constructor will put the questions the form has into the ArrayList of questions
        _questions = getQuestions();
    }

    public void createReport() {
        
        InjuryReportData data = new InjuryReportData();
        data._firstName = "first"; //this needs to be pulled from Form
        data._lastName = "last"; //this needs to be pulled from Form
        data._identifier = "email"; //tis needs to be pulled from Form
        data._dayInjuryOccured = "Monday"; //this needs to be pulled from Form
        data._injuryDuration = "1 day"; //this needs to be pulled from Form
        data._intensity = "4"; //this needs to be pulled from Form

        InMemoryStorage storage = new InMemoryStorage();
        storage.createInjuryReport(data);
    }

    //getter
    public static ArrayList<String> getQuestions() {
        return Form.getQuestions();
    }

    //toString
    @Override
    public String toString() {
        return null;
    }
}
