/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.util.ArrayList;

/**
 *
 * @author elngo
 */
public class RegisteredUsers {
    private ArrayList<Athlete> _registeredAthletes;
    private ArrayList<Trainer> _registeredTrainers;
    
    //getters
    public ArrayList<Athlete> getRegisteredAthletes()
    {
        return _registeredAthletes;
    }
    
    public ArrayList<Trainer> getRegisteredTrainers()
    {
        return _registeredTrainers;
    }
    
    //toString
    @Override
    public String toString()
    {
        
    }
}
