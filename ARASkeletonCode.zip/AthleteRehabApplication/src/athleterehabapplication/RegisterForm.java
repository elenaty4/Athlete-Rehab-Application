/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import java.util.ArrayList;

/**
 *
 * @author elngo
 */
public class RegisterForm extends Form {
    
    //public RegisterForm generateRegistrationForm
    //I take away this method because we can simply use a toString method to
    //receive the RegisterForm
    
    public RegisterForm()
    {
        //constructor will put the questions the form has into the ArrayList of questions
    }
    
    //getter
    @Override
    public ArrayList<String> getQuestions()
    {
        return super.getQuestions();
    }
    
    //toString
    @Override
    public String toString()
    {
        
    }
}
