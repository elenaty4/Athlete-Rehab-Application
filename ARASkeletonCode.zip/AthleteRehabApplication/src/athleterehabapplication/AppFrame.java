/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package athleterehabapplication;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 *
 * @author elngo
 */
public class AppFrame extends JFrame {
    
    final private int FRAME_WIDTH = 900; //numbers are subject to change
    final private int FRAME_HEIGHT= 600;
    
    private JFrame _frame;
    private JPanel _panel;
    private JButton _button;
    private JTextField _textField;
    
    private ActionListener _listener; //listens to what the mouse clicks
    
    public AppFrame()
    {
        //will call frameComponents
    }
    
    private void frameComponents() //private method because it is only used in this class
    {
        
    }
    
    //more methods may be created soon
    
    /**
    * This class listens to the user's clicks in the application
    */    
    public class ClickListener implements ActionListener{
        
        @Override
        public void actionPerformed(ActionEvent event)
        {
            
        }
    }
}
